UPDATE `settings` SET `setting_value`='1.2' WHERE `setting_key`='current_version';

CREATE TABLE `documents`(
    `document_id` int(10) unsigned NOT NULL  auto_increment , 
    `file` varchar(150) COLLATE utf8_general_ci NULL  DEFAULT '' , 
    `extenstion` varchar(4) COLLATE utf8_general_ci NULL  DEFAULT '' , 
    `description` varchar(400) COLLATE utf8_general_ci NULL  DEFAULT '' , 
    `location` varchar(100) COLLATE utf8_general_ci NULL  DEFAULT '' , 
    `uploaded` datetime NULL  , 
    `type` varchar(150) COLLATE utf8_general_ci NULL  DEFAULT '' , 
    PRIMARY KEY (`document_id`) 
) ENGINE=InnoDB DEFAULT CHARSET='utf8';

CREATE TABLE `documents_permissions`(
    `document_id` int(10) unsigned NULL  , 
    `type` varchar(20) COLLATE utf8_general_ci NULL  , 
    `value` varchar(20) COLLATE utf8_general_ci NULL  , 
    KEY `Index 2`(`type`,`document_id`) 
) ENGINE=InnoDB DEFAULT CHARSET='utf8';

ALTER TABLE `vacancies_applicants` 
    ADD COLUMN `current_employee` smallint(5) unsigned   NULL DEFAULT 0 after `employee_id` , 
    CHANGE `hired_at` `hired_at` date   NULL after `current_employee` ;