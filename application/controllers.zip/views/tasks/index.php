<?php $this->load->view('layout/header', array('title' => $this->lang->line('Tasks'), 'forms' => TRUE, 'tables' => TRUE, 'icheck' => TRUE, 'magicsuggest' => TRUE)) ?>
<script>
    $('document').ready(function () {
        $('#reAssign').click(function () {
            var that = $(this);
            var values = new Array();
            $.each($("input[name='checkHead[]']:checked"), function () {
                values.push($(this).val());
            });

            if (values.length > 0) {
//                console.log(JSON.stringify(values));
//                that.attr('href', url);
                return true;
            } else {
                alert("Please select at least one item. ");
                return false;
            }
        });

        $('#modal_window').on('shown.bs.modal', function (e) {

            var values = new Array();
            $.each($("input[name='checkHead[]']:checked"), function () {
                values.push($(this).val());
            });
            var url = $('#reAssign').attr('href');
            $.ajax({
                cache: false,
                type: 'POST',
                url: url,
                data: 'task_ids=' + JSON.stringify(values),
                success: function (data) {
                    $('#modal_window').html(data);
                }
            });
        });

        //$(".knob").knob();
        current_table = $('.data_table').dataTable({
//            "order": [[6, "desc"]],
            "columnDefs": [{
                    "targets": [0, 1, 8],
                    "orderable": false
                }]
        });
        $('.pop-btn').hover(function () {
            var pop = $(this).attr('data-pop');
            $(pop).show();
        }, function () {
            var pop = $(this).attr('data-pop');
            $(pop).fadeOut();
        });
<?php if (isset($is_selfservice)) { ?>
            var ms = $('#employee').magicSuggest({
                placeholder: 'Filter By Employee',
                allowFreeEntries: false,
                data: 'schedule/find_employee',
                maxSelection: 1
            });
    <?php if (isset($employee)) { ?>
                ms.setSelection([{name: '<?= $employee['name'] ?>', id:<?= $employee['employee_id'] ?>}]);
    <?php } ?>
            $(ms).on('selectionchange', function (e, m) {
                $('#employee_id').val(this.getValue());
                $('#filterByEmployee').submit();
            });
<?php } ?>
    });
</script>
<div id="wrapper">
    <?php $this->load->view('layout/menu', array('active_menu' => $active_menu)) ?>
    <div id="page-wrapper" class="gray-bg">
        <?php $this->load->view('layout/page_header') ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-5">
                <h2><?= $this->lang->line('Tasks') ?></h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="dashboard"><?= $this->lang->line('Home') ?></a>
                    </li>
                    <li>
                        <?= $this->lang->line('List') ?>
                    </li>
                </ol>
            </div>
            <div class="col-lg-4">
                <div class="form-group" style="padding-top: 30px;">
                    <?php if (!$is_selfservice) { ?>
                        <input type="text" id="employee" name="employee">
                        <form action="" method="GET" id="filterByEmployee">
                            <input type="hidden" value="" id="employee_id" name="employee_id" />
                        </form>
                    <?php } ?>
                </div>
            </div>
            <div class="col-lg-2" style="padding-top: 30px;">
                <div class="btn-group pull-right" role="group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Action
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="tasks/re_assign" id="reAssign" data-toggle="modal" data-target="#modal_window"><i class="fa fa-user"></i> Assign to</a></li>
                        <?php if (isset($employee)) { ?>
                        <li><a target="_blank" href="tasks/print_employee_tasks/<?= $employee['employee_id'] ?>/<?=$type?>" id="printTaskList" ><i class="fa fa-file-pdf-o"></i> Print</a></li>
                        <?php } ?>                        
<!--<li><a href="#" id="deleteAll"><i class="fa fa-trash-o"></i> Delete</a></li>-->

                    </ul>
                </div>
            </div>
            <div class="col-lg-1">
                <div class="title-action">
                    <a href="tasks/new_task" class="btn btn-primary" >
                        <i class="fa fa-plus-circle"></i>
                        <?= $this->lang->line('Add') ?>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInDown">
                    <div class="ibox-content">
                        <div class="row">
                            <div id="save_result"></div>
                            <table class="table table-striped table-bordered table-hover data_table" >
                                <thead>
                                    <tr>
                                        <th class="text-center">
                                            <label>
                                                <input type="checkbox" name="checkHead" class="i-checks checkHead" id="selectall"/>
                                                <span class="lbl"></span>
                                            </label>
                                        </th>
                                        <td width="7%"></td>
                                        <th width="12%"><?= $this->lang->line('Task process') ?></th>
                                        <th><?= $this->lang->line('Title') ?></th>
                                        <th width="4%"></th>
                                        <th width="4%"></th>
                                        <th><?= $this->lang->line('Assigned to') ?></th>
                                        <th><?= $this->lang->line('Start Date') ?></th>
                                        <th><?= $this->lang->line('Due Date') ?></th>
                                        <th width="7%"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($tasks as $task) { ?>
                                        <tr entity_id="<?= $task['task_id'] ?>">
                                            <td class="text-center">
                                                <label>
                                                    <input type="checkbox" class="i-checks checkItem" name="checkHead[]" value="<?= $task['task_id'] ?>" />
                                                    <span class="lbl"></span>
                                                </label>
                                            </td>
                                            <td>
                                                <div  class="pop-container">
                                                    <a class="btn btn-outline btn-info btn-xs" href="tasks/comment_task/<?= $task['task_id'] ?>" data-toggle="tooltip" data-placement="top" title="Communication">
                                                        <i class="fa fa-commenting"></i>
                                                    </a>
                                                    <a class="btn btn-outline btn-primary btn-xs pop-btn" data-pop="#pop<?= $task['task_id'] ?>">
                                                        <i class="fa fa-eye"></i>
                                                    </a>
                                                    <div class="pop-dialog" id="pop<?= $task['task_id'] ?>"><?= $task['description'] ?></div>                                                
                                                </div>
                                            </td>
                                            <td>
                                                <!--<input type="text" class="knob" value="<?php echo $task['process']; ?>" data-thickness="0.2" data-width="40" data-height="40" data-fgColor="#00a65a" data-readonly="true">-->
                                                <div class="progress" style="margin-bottom: 0;">
                                                    <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $task['process']; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $task['process']; ?>%;">
                                                        <?php echo $task['process']; ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?= $task['task_title'] ?></td>
                                            <td class="text-center text-danger"><?= $task['additional']?></td>
                                            <td class="text-center text-danger"><?= ($task['task_regular'] == 1) ? 'R' : '' ?></td>
                                            <td><?php echo ($task['task_responsible']) ? $task['task_responsible'] : 'Not Assigned' ?></td>
                                            <td><?= $task['start_date'] ?></td>
                                            <td><?php echo ($task['due_date'] == '0000-00-00' || $task['due_date'] == null) ? '' : $task['due_date'] ?></td>
                                            <td>

                                                <a class="btn btn-outline btn-success btn-xs" href="tasks/edit_task/<?= $task['task_id'] ?>" >
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a class="btn btn-outline btn-danger btn-xs" onclick="confirm('Delete task ?') && submit_form('#delete_task<?= $task['task_id'] ?>', '#save_result')" title="Delete">
                                                    <i class="fa fa-trash-o"></i>
                                                </a>

                                                <form action="tasks/delete_task" method="POST" id="delete_task<?= $task['task_id'] ?>">
                                                    <input type="hidden" id="task_id" name="task_id" value="<?= $task['task_id'] ?>" class="task_id<?= $task['task_id'] ?>">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</div>
<?php
$this->load->view('layout/footer')?>