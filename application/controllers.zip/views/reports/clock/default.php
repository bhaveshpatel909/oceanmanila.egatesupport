<table class="table table-striped table-bordered table-hover data_table">
    <thead>
        <tr>
            <?php if (isset($data[0]['name'])) { ?>
                <th><?= $this->lang->line('Employee') ?></th>
            <?php } ?>
            <th><?= $this->lang->line('Dates') ?></th>
            <th><?= $this->lang->line('In Time') ?></th>
            <th><?= $this->lang->line('Out Time') ?></th>
            <th><?= $this->lang->line('Working Hour') ?></th>
            <th><?= $this->lang->line('Comments') ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        $current_date = '';
        $total_hours = 0;
        foreach ($data as $record) {
            $start_time_unix = strtotime($record['start_time']);
            $end_time_unix = strtotime($record['end_time']);
            ?>
            <tr>
                <?php if (isset($record['name'])) { ?>
                    <td>
                        <img src="<?= $record['avatar'] ?>" class="img-circle col-lg-3 col-md-3 col-sm-4 col-xs-5"/>
                        <?= $record['name'] ?><br> [<?= $record['department_name'] ?>] <?= $record['position_name'] ?>
                    </td>
                <?php } ?>
                <td>
                    <?php
                    if ($current_date != $record['date_id']) {
                        $current_date = $record['date_id'];
                        ?>
                        <strong><?= date($this->config->item('date_format'), $start_time_unix) ?></strong>
                    <?php } ?>

                </td>
                <td><?= date('Y-m-d', strtotime($record['start_time'])) ?> <span class="text-primary text-bold"><?= date('H:i', strtotime($record['start_time'])) ?></span></td>
                <td>
                    <?php if($record['end_time']) {?>
                    <?php if (date('Y-m-d',strtotime($record['start_time']))!=date('Y-m-d',strtotime($record['end_time']))) {?>
                    <?= date('Y-m-d', strtotime($record['end_time'])) ?> 
                    <?php } ?>
                    <span class="text-primary text-bold"><?= date('H:i', strtotime($record['end_time'])) ?></span>
                    <?php } ?>
                </td>
                <td class="text-right text-danger text-bold">
                    <?php
//                    $datetime1 = new DateTime($record['start_time']);
//                    $datetime2 = new DateTime($record['end_time']);
//                    $interval = $datetime1->diff($datetime2);
//                    //$elapsed = $interval->format('%y years %m months %a days %h hours %i minutes %S seconds');
//                    $elapsed = $interval->format('%H:%I:%S');
//                    $days = $interval->format('%a');
//                    $hours = $interval->format('%H') + ($days * 24);
//                    $mins = $interval->format('%I');
//                    $senconds = $interval->format('%S');
//                    echo sprintf("%'.02d", $hours) . ":" . $mins . ":" . $senconds;
                    $diff = strtotime($record['end_time']) - strtotime($record['start_time']);
                    if ($diff > 0) {
                        $days = floor($diff / 86400);
                        $hours = floor(($diff % 86400) / 3600);
                        $mins = floor((($diff % 86400) % 3600) / 60);
                        $senconds = floor((($diff % 86400) % 3600) % 60);
                        //echo (int) $days . ':'. ($diff % 86400);
                        echo sprintf("%'.02d", ($days * 24 + $hours)) . ':' . sprintf("%'.02d", $mins) ;//. ':' . sprintf("%'.02d", $senconds);
                        $total_hours += $diff;
                    }
                    ?>
                </td>
                <td><?= $record['comments'] ?></td>
            </tr>
        <?php } ?>
    </tbody>
    <tfoot>
        <tr>
            <?php if (isset($data[0]['name'])) { ?>
                <th></th>
            <?php } ?>
            <th colspan="3" style="text-align: right;font-weight: 700;"><?= $this->lang->line('Total time') ?></th>
            <td style="font-weight: 700;" class="text-danger text-bold text-right"><?php
                $days = floor($total_hours / 86400);
                $hours = floor(($total_hours % 86400) / 3600);
                $mins = floor((($total_hours % 86400) % 3600) / 60);
                $senconds = floor((($total_hours % 86400) % 3600) % 60);
                //echo (int) $days . ':'. ($diff % 86400);
                echo sprintf("%'.02d", ($days * 24 + $hours)) . ':' . sprintf("%'.02d", $mins) ;//. ':' . sprintf("%'.02d", $senconds);
                ?></td>
            <td>

            </td>
        </tr>
    </tfoot>
</table>

<form target="_blank" action="reports/print_punch_clock" method="POST" id="print_punch_clock">
    <input type="hidden" name="jsondata" id="jsondata" value='<?= $postdata ?>' />
</form>
<div class="clearfix m-t-lg"></div>