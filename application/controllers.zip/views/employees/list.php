<?php 
$i = 0;
foreach ($employees['data'] as $employee) { 
    $i++;
    ?>
    <div class="col-lg-4 person_area">
        <div class="contact-box">
            <a href="employees/edit_employee/<?= $employee['employee_id'] ?>">
                <div class="col-sm-3">
                    <div class="text-center">
                        <img class="img" style="width: 80%;" src="<?= $employee['avatar'] ?>">
                        <?php if ($employee['is_active'] == 1) { ?>
                            <span class="badge badge-success m-t-xs"><?= $this->lang->line('Active') ?></span>
                        <?php } else { ?>
                            <span class="badge badge-default m-t-xs"><?= $this->lang->line('Inactive') ?></span>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-sm-8">
                    <h3><strong><?= $employee['name'] ?></strong></h3>
                    <span>[<?= $employee['department_name'] ?>] <?= $employee['position_name'] ?></span>
                </div>
                <?php
                $diff = strtotime($employee['contract_expiry']) - strtotime(date('Y-m-d'));
                $days = 0;
                if ($diff > 0) {
                    $days = floor($diff / 86400);
                }
                ?>
                <label class="control-label text-danger " style="font-size: 17px"><?= $days ?></label>
                <div class="clearfix"></div>
            </a>
        </div>
    </div>
    <?php
    if($i % 3 == 0) {
        echo '<div class="clearfix"></div>';
    }
}?>