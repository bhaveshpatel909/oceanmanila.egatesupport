<?php $this->load->view('layout/header', array('title' => $this->lang->line('Edit employee'), 'forms' => TRUE, 'date_time' => TRUE, 'icheck' => TRUE)) ?>
<script>
    $('document').ready(function () {
        $('.btn-group button').click(function () {
            $('.btn-group button').removeClass('active btn-primary');
            $(this).addClass('active btn-primary');
            $("#employee_gender").val($(this).attr('gender'));
        });

        $("#employee_avatar").change(function () {
            $("#save_result").html('<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#">&times;</a><?= $this->lang->line('Press Save button and photo will be updated') ?></div>');
        });

        $('.datetimepicker').datetimepicker({pickTime: false});
    });
</script>
<script language="JavaScript">
    Webcam.set({
        width: 320,
        height: 240,
        // device capture size
        dest_width: 320,
        dest_height: 240,
        // final cropped size
        crop_width: 240,
        crop_height: 240,
        image_format: 'jpeg',
        jpeg_quality: 100,
        force_flash: true
    });

    function setup() {
        $('#my_camera').show();
        Webcam.attach('#my_camera');
    }

    function take_snapshot() {
        // take snapshot and get image data
//        Webcam.freeze();
        Webcam.snap(function (data_uri) {
            // display results in page
            $('#avatar_img').attr('src', data_uri);
//            document.getElementById('results').innerHTML =
//                    '<h2>Here is your image:</h2>' +
//                    '<img src="' + data_uri + '"/>';
            var url = 'employees/upload_avatar?employee_id=' + <?= $employee['employee_id'] ?>;
            Webcam.upload(data_uri, url, function (code, text) {
                // Upload complete!
                // 'code' will be the HTTP response code from the server, e.g. 200
                // 'text' will be the raw response content
            });
        });
        Webcam.reset();
        $('#my_camera').hide();
        $('#takephoto').hide();
        $('#openCamera').show();
    }
</script>
<?php $this->load->view('mix/attachment_remove') ?>
<div id="wrapper">
    <?php $this->load->view('layout/menu', array('active_menu' => 'employees')) ?>
    <div id="page-wrapper" class="gray-bg">
        <?php $this->load->view('layout/page_header') ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-8">
                <h2><?= $this->lang->line('Edit') ?></h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="dashboard"><?= $this->lang->line('Home') ?></a>
                    </li>
                    <li>
                        <?= $this->lang->line('Employees') ?>
                    </li>
                </ol>
            </div>
            <div class="col-lg-4">
                <div class="title-action">
                    <a target="_blank" href="employees/print_employee/<?= $employee['employee_id'] ?>"  class="btn btn-primary" >
                        <i class="fa fa-file-pdf-o"></i>
                        <?= $this->lang->line('Print ID') ?>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInDown">
                    <div class="row">
                        <div id="save_result"></div>
                        <div class="col-lg-4">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5><?= $this->lang->line('Details') ?></h5>
                                </div>
                                <div>
                                    <form action="employees/save_employee" id="save_details" method="POST" role="form">
                                        <input type="hidden" name="employee_id" id="employee_id" value="<?= $employee['employee_id'] ?>">
                                        <div class="ibox-content no-padding border-left-right text-center">
                                            <a >
                                                <img id="avatar_img" class="img-circle" src="<?= $employee['avatar'] ?>" style="width: 140px;height: 140px">
                                            </a>
                                            <div id="my_camera"></div>
                                            <input type="file" id="employee_avatar" name="employee_avatar" accept="image/*" class="hide">
                                            <br />
                                            <button type="button" class="btn btn-default m-t-xs" onclick="$('#employee_avatar').click();return false;">
                                                <i class="fa fa-folder-open"></i>
                                                Browse...
                                            </button>
                                            <button type="button" class="btn btn-primary m-t-xs" id="openCamera"  onclick="setup(); $(this).hide().next().show();">
                                                <i class="fa fa-camera"></i>
                                                Turn on camera
                                            </button>
                                            <button type="button" class="btn btn-primary m-t-xs" id="takephoto" onclick="take_snapshot()" style="display:none">
                                                <i class="fa fa-camera"></i>
                                                Take a photo
                                            </button>
                                            <br/>
                                            <?php if ($employee['is_active'] == 1) { ?>
                                                <span class="badge badge-success m-t-xs" id="employee_status"><?= $this->lang->line('Active') ?></span>
                                            <?php } else { ?>
                                                <span class="badge badge-default m-t-xs" id="employee_status"><?= $this->lang->line('Inactive') ?></span>
                                            <?php } ?>
                                        </div>
                                        <div class="ibox-content profile-content">
                                            <div class="form-group has-feedback">
                                                <label for="employee_name" class="control-label"><?= $this->lang->line('Name') ?><sup class="mandatory">*</sup></label>
                                                <input type="text" name="employee_name" id="employee_name" class="form-control required" maxlength="100" value="<?= $employee['name'] ?>">
                                            </div>
                                            <div class="form-group has-feedback">
                                                <label for="employee_email" class="control-label"><?= $this->lang->line('Email') ?><sup class="mandatory">*</sup></label>
                                                <input type="email" name="employee_email" id="employee_email" class="form-control required email" maxlength="100" value="<?= $employee['email'] ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="birth_date" class="control-label"><?= $this->lang->line('Birth date') ?></label>
                                                <input type="text" name="birth_date" id="birth_date" class="form-control datetimepicker" value="<?= ($employee['birth_date']) ? date($this->config->item('date_format'), strtotime($employee['birth_date'])) : '' ?>" data-date-format="<?= $this->config->item('js_month_format') ?>">
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-5" >
                                                    <label class="control-label"><?= $this->lang->line('Gender') ?></label>                                                
                                                </div>
                                                <div class="col-lg-7">
                                                    <input type="hidden" name="employee_gender" id="employee_gender" value="<?= $employee['gender'] ?>">
                                                    <div class="btn-group" data-toggle="buttons">
                                                        <button type="button" class="btn btn-circle <?= ($employee['gender'] == 'male') ? 'btn-primary active' : '' ?>" gender="male"><i class="fa fa-male" style="font-size: 19px;"></i></button>
                                                        <button type="button" class="btn btn-circle <?= ($employee['gender'] == 'female') ? 'btn-primary active' : '' ?>" gender="female"><i class="fa fa-female" style="font-size: 19px;"></i></button>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-5">
                                                    <label for="employee_ssn" class="control-label"><?= $this->lang->line('SSS No.') ?></label>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group">
                                                        <input type="text" name="employee_ssn" id="employee_ssn" class="form-control" maxlength="40" value="<?= $employee['ssn'] ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-5">
                                                    <label class="control-label"><?= $this->lang->line('TIN No.') ?></label>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group">
                                                        <input type="text" name="employee_tin" id="employee_tin" class="form-control" maxlength="40" value="<?= $employee['tin'] ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-5">
                                                    <label class="control-label"><?= $this->lang->line('PhilHealth No.') ?></label>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group">
                                                        <input type="text" name="employee_healthno" id="employee_healthno" class="form-control" maxlength="40" value="<?= $employee['healthno'] ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-5">
                                                    <label class="control-label text-primary"><?= $this->lang->line('Contract Ends') ?></label>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group">
                                                        <?php
                                                        $diff = strtotime($employee['contract_expiry']) - strtotime(date('Y-m-d'));
                                                        $days = 0;
                                                        if ($diff > 0) {
                                                            $days = floor($diff / 86400);
                                                        }
                                                        ?>
                                                        <label class="control-label text-primary"><?=$days?></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-primary pull-right" onclick="submit_form('#save_details')">
                                                <i class="fa fa-save"></i>
                                                <?= $this->lang->line('Save') ?>
                                            </button>
                                            <?php
                                            $userdata = $this->session->userdata();
                                            if ($this->user_actions->is_allowed('admin') && $employee['employee_id'] != '1') {
                                                ?>
                                                <a href="employees/set_password/<?= $employee['employee_id'] ?>" class="pull-right m-r-sm m-t-sm" data-target="#modal_window" data-toggle="modal"><?= $this->lang->line('Access') ?></a>
                                                <?php
                                            } elseif ($employee['employee_id'] == '1' && $userdata['employee_id'] == '1') {
                                                ?>
                                                <a href="employees/set_password/<?= $employee['employee_id'] ?>" class="pull-right m-r-sm m-t-sm" data-target="#modal_window" data-toggle="modal"><?= $this->lang->line('Access') ?></a>
                                                <?php
                                            }
                                            ?>
                                            <div class="clearfix"></div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="ibox float-e-margins">
                                <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/new_contract/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                    <i class="fa fa-plus-circle"></i>
                                    <?= $this->lang->line('Add') ?>
                                </a>
                                <div class="ibox-title " id="employees_contract_click">
                                    <h5><?= $this->lang->line('Contract') ?></h5>
                                </div>
                                <div class="ibox-content" id="employees_contract"  ajax_link="employees/contract/<?= $employee['employee_id'] ?>">
                                    <?php $this->load->view('employees/contract', $contracts)?>
                                </div>
                            </div>    
                            <div class="ibox float-e-margins">
                                <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/new_license/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                    <i class="fa fa-plus-circle"></i>
                                    <?= $this->lang->line('Add') ?>
                                </a>
                                <div class="ibox-title collapse-link" id="employees_licenses_click">
                                    <h5><?= $this->lang->line('Required Documents') ?></h5>
                                </div>
                                <div class="ibox-content" id="employees_licenses"  ajax_link="employees/licenses/<?= $employee['employee_id'] ?>">
                                    <?php $this->load->view('employees/licenses', $licenses)?>
                                </div>
                            </div>

                            <div class="ibox float-e-margins">
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Position') ?></h5>
                                </div>
                                <div class="ibox-content" style="display: none;">
                                    <form action="employees/save_position" id="save_position" method="POST" role="form">
                                        <input type="hidden" name="employee_id" id="employee_id" value="<?= $employee['employee_id'] ?>">

                                        <div class="col-lg-6 no-padding form-group">
                                            <select name="position_id" id="position_id" class="form-control required">
                                                <option value="">Select Position</option>
                                                <?php foreach ($positions as $position) { ?>
                                                    <option <?php echo ($position['position_id'] == $employee['position_id']) ? 'selected' : '' ?> value="<?= $position['position_id'] ?>"><?= $position['position_name'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>

                                        <div class="clearfix"></div>
                                        <button type="button" class="btn btn-primary pull-right" onclick="submit_form('#save_position')">
                                            <i class="fa fa-save"></i>
                                            <?= $this->lang->line('Save') ?>
                                        </button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>

                            <div class="ibox float-e-margins">
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Department') ?></h5>
                                </div>
                                <div class="ibox-content" style="display: none;">
                                    <form action="employees/save_department" id="save_department" method="POST" role="form">
                                        <input type="hidden" name="employee_id" id="employee_id" value="<?= $employee['employee_id'] ?>">

                                        <div class="col-lg-6 no-padding form-group">
                                            <select name="department_id" id="department_id" class="form-control required">
                                                <option value="">Select Department</option>
                                                <?php foreach ($departments as $department) { ?>
                                                    <option <?php echo ($department['department_id'] == $employee['department_id']) ? 'selected' : '' ?> value="<?= $department['department_id'] ?>"><?= $department['department_name'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>

                                        <div class="clearfix"></div>
                                        <button type="button" class="btn btn-primary pull-right" onclick="submit_form('#save_department')">
                                            <i class="fa fa-save"></i>
                                            <?= $this->lang->line('Save') ?>
                                        </button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>

                            <div class="ibox float-e-margins">
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Address') ?></h5>
                                </div>
                                <div class="ibox-content" style="display: none;">
                                    <form action="employees/save_address" id="save_address" method="POST" role="form">
                                        <input type="hidden" name="employee_id" id="employee_id" value="<?= $employee['employee_id'] ?>">
                                        <div class="form-group">
                                            <label for="employee_address" class="control-label"><?= $this->lang->line('Address') ?></label>
                                            <input type="text" name="employee_address" id="employee_address" class="form-control" value="<?= $employee['address'] ?>" maxlength="100">
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="col-lg-5 form-group" style="padding-left: 0;">
                                            <label for="employee_city" class="control-label"><?= $this->lang->line('City') ?></label>
                                            <input type="text" name="employee_city" id="employee_city" class="form-control" value="<?= $employee['city'] ?>" maxlength="100">
                                        </div>
                                        <div class="col-lg-4 form-group" style="padding-left: 0;">
                                            <label for="employee_state" class="control-label"><?= $this->lang->line('State') ?></label>
                                            <input type="text" name="employee_state" id="employee_state" class="form-control" value="<?= $employee['state'] ?>" maxlength="100">
                                        </div>
                                        <div class="col-lg-3 form-group" style="padding-left: 0;">
                                            <label for="employee_zip" class="control-label"><?= $this->lang->line('Zip') ?></label>
                                            <input type="text" name="employee_zip" id="employee_zip" class="form-control" value="<?= $employee['zip_code'] ?>" maxlength="10">
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="col-lg-6 form-group" style="padding-left: 0;">
                                            <label for="employee_phone" class="control-label"><?= $this->lang->line('Phone') ?></label>
                                            <input type="tel" name="employee_phone" id="employee_phone" class="form-control" value="<?= $employee['phone'] ?>" maxlength="100">
                                        </div>
                                        <div class="col-lg-6 form-group" style="padding-left: 0;">
                                            <label for="employee_cell_phone" class="control-label"><?= $this->lang->line('Cell') ?></label>
                                            <input type="text" name="employee_cell_phone" id="employee_cell_phone" class="form-control" value="<?= $employee['cell_phone'] ?>" maxlength="100">
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="col-lg-12 form-group" style="padding-left: 0;">
                                            <label for="contacts" class="control-label"><?= $this->lang->line('Emergency contacts') ?></label>
                                            <textarea rows="4" name="contacts" id="contacts" class="form-control"></textarea>
                                        </div>
                                        <div class="clearfix"></div>
                                        <button type="button" class="btn btn-primary pull-right" onclick="submit_form('#save_address')">
                                            <i class="fa fa-save"></i>
                                            <?= $this->lang->line('Save') ?>
                                        </button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>

                            <!--
                                                        <div class="ibox float-e-margins">
                                                            <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/edit_skills/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                                                <i class="fa fa-edit"></i>
                            <?= $this->lang->line('Edit') ?>
                                                            </a>
                                                            <div class="ibox-title collapse-link">
                                                                <h5><?= $this->lang->line('Skills') ?></h5>
                                                            </div>
                                                            <div class="ibox-content" id="employees_skills" style="display: none;" ajax_link="employees/skills/<?= $employee['employee_id'] ?>"></div>
                                                        </div>
                            -->
                            <div class="ibox float-e-margins">
                                <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/new_employment/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                    <i class="fa fa-plus-circle"></i>
                                    <?= $this->lang->line('Add') ?>
                                </a>
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Employment') ?></h5>
                                </div>
                                <div class="ibox-content" id="employees_employment" style="display: none;" ajax_link="employees/employment/<?= $employee['employee_id'] ?>"></div>
                            </div>

                            <div class="ibox float-e-margins">
                                <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/new_education/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                    <i class="fa fa-plus-circle"></i>
                                    <?= $this->lang->line('Add') ?>
                                </a>
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Education') ?></h5>
                                </div>
                                <div class="ibox-content" id="employees_education" style="display: none;" ajax_link="employees/education/<?= $employee['employee_id'] ?>"></div>
                            </div>

                            <div class="ibox float-e-margins">
                                <a class="pull-right btn btn-primary btn-sm m-t-sm m-r-sm" href="employees/new_relative/<?= $employee['employee_id'] ?>" data-target="#modal_window" data-toggle="modal">
                                    <i class="fa fa-plus-circle"></i>
                                    <?= $this->lang->line('Add') ?>
                                </a>
                                <div class="ibox-title collapse-link">
                                    <h5><?= $this->lang->line('Family') ?></h5>
                                </div>
                                <div class="ibox-content" id="employees_family" style="display: none;" ajax_link="employees/relatives/<?= $employee['employee_id'] ?>"></div>
                            </div>

                            

                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$this->load->view('layout/footer')?>