<?php $this->load->view('layout/header', array('title' => $this->lang->line('Schedules'), 'forms' => TRUE, 'tables' => TRUE, 'icheck' => TRUE, 'magicsuggest' => TRUE)) ?>
<script>
    $('document').ready(function () {
        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },
            defaultDate: '<?= date("Y-m-d") ?>',
            editable: true,
            eventLimit: true, // allow "more" link when too many events
            events: {
                url: 'schedule/calendar/<?= $employee_id ?>',
                error: function () {
                    $('#script-warning').show();
                }
            },
            loading: function (bool) {
                $('#loading').toggle(bool);
            },
            eventMouseover: function (event, jsEvent, view) {
                var buttons = '<div class="schedule-popover">';
                buttons += '<button href="schedule/preview_schedule/' + event.id + '" title="Preview" type="button" class="btn btn-outline btn-primary btn-xs" data-target="#modal_window" data-toggle="modal">';
                buttons += '<i class="fa fa-eye"></i>';
                buttons += '</button> &nbsp;&nbsp;';
                buttons += '<button title="Edit" type="button" class="btn btn-outline btn-success btn-xs" onclick="window.location=\'schedule/edit_schedule/' + event.id + '\'" >';
                buttons += '<i class="fa fa-edit"></i>';
                buttons += '</button> &nbsp;&nbsp;';
                buttons += '<button title="Delete" type="button" class="btn btn-outline btn-danger btn-xs" onclick="confirm(\'Delete Schedule?\') && deleteSchedule(' + event.id + ')" >';
                buttons += '<i class="fa fa-trash-o"></i>';
                buttons += '</button>';
                buttons += '</div>';
                $(this).append(buttons);
            },
            eventMouseout: function (event, jsEvent, view) {
                $('.schedule-popover').remove();
            }
        });
        var ms = $('#employee').magicSuggest({
            placeholder: 'Filter By Employee',
            allowFreeEntries: false,
            data: 'schedule/find_employee',
            maxSelection: 1

        });
<?php if (!is_null($employee_id)) { ?>
            ms.setSelection([{name: '<?= $employee['name'] ?>', id:<?= $employee['employee_id'] ?>}]);
<?php } ?>
        $(ms).on('selectionchange', function (e, m) {
            window.location.href = 'schedule/index/' + this.getValue();
        });
    });
    function deleteSchedule(id) {
        $('#save_result').html('<img src="images/ajax-loader.gif" />');
        $.ajax({
            url: 'schedule/delete_schedule/' + id,
            success: function (data) {
                response = $.parseJSON(data);
                if (response.error != 1) {
                    $('#calendar').fullCalendar('removeEvents', id);
                    $("#save_result").html('<?php $this->load->view('layout/success', array('message' => $this->lang->line('Deleted'))) ?>');
                } else {
                    $("#save_result").html('<?php $this->load->view('layout/error', array('message' => $this->lang->line('Error! Cannot delete event. Please try again!'))) ?>');
                }
            }
        });
    }
</script>
<div id="wrapper">
    <?php $this->load->view('layout/menu', array('active_menu' => 'schedule_calendar')) ?>
    <div id="page-wrapper" class="gray-bg">
        <?php $this->load->view('layout/page_header') ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-6">
                <h2><?= $this->lang->line('Schedules') ?></h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="dashboard"><?= $this->lang->line('Home') ?></a>
                    </li>
                    <li>
                        <?= $this->lang->line('Schedules') ?>
                    </li>
                </ol>
            </div>
            <div class="col-lg-4">
                <div class="form-group" style="padding-top: 30px;">
                    <input type="text" id="employee" name="employee">
                </div>
            </div>
            <div class="col-lg-2">
                <div class="title-action">                    
                    <a href="schedule/new_schedule" class="btn btn-primary">
                        <i class="fa fa-plus-circle"></i>
                        <?= $this->lang->line('Add') ?>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInDown">
                    <div class="ibox-content">
                        <div class="row">
                            <div id="save_result"></div>
                            <div id='loading'>loading...</div>
                            <div id='calendar' class="col-lg-12"></div>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</div>
<?php
$this->load->view('layout/footer')?>