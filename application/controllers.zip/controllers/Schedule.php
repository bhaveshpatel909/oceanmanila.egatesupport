<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_schedule $db
 * @property CI_Session          $session
 * @property schedule_actions          $schedule_actions
 */
class Schedule extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->load->model('schedule_actions');
        $this->user_actions->is_loged_in('tasks');
        $this->load->helper('url');
    }

    function index($employee_id = null) {
        $this->load->model('employees_actions');
        $employee = null;
        if (!is_null($employee_id)) {
            $employee = $this->employees_actions->get_employee($employee_id);
        }
        $this->load->view('schedule/index', array('employee_id' => $employee_id, 'employee' => $employee));
    }

    function calendar($employee_id = null) {
        // Short-circuit if the client did not give us a date range.
        if (!isset($_GET['start']) || !isset($_GET['end'])) {
            die("Please provide a date range.");
        }

        $start_date = $this->input->get('start');
        $end_date = $this->input->get('end');
        
        $output_arrays = $this->schedule_actions->get_schedule_calendar($start_date, $end_date, $employee_id);
        //_custom_debug($output_arrays);
// Send JSON to the client.
        echo json_encode($output_arrays);
    }

    function daily() {
        $this->load->view('schedule/daily_schedules', array('schedules' => $this->schedule_actions->get_schedule_daily()));
    }

    function new_schedule() {
        $is_selfservice = $this->user_actions->is_selfservice();
        $employee_id = $this->session->userdata('employee_id');
        $schedule_items = $this->schedule_actions->get_schedule_items();
        $customer_items = $this->schedule_actions->get_customer_items();
        $this->load->view('schedule/schedule_new', array('schedule_items' => $schedule_items, 'customer_items' => $customer_items, 'is_selfservice' => $is_selfservice, 'employee_id' => $employee_id));
    }

    function edit_schedule($schedule_id = 0) {
        $is_selfservice = $this->user_actions->is_selfservice();
        $schedule_items = $this->schedule_actions->get_schedule_items();
        $customer_items = $this->schedule_actions->get_customer_items();
        $this->load->view('schedule/schedule_edit', array(
            'schedule' => $this->schedule_actions->get_schedule($schedule_id),
            'schedule_items' => $schedule_items,
            'customer_items' => $customer_items,
            'is_selfservice' => $is_selfservice
        ));
    }

    function save_schedule() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'schedule_id', 'rules' => 'required', 'label' => 'schedule_id'),
            array('field' => 'schedule_item_id', 'rules' => 'required', 'label' => $this->lang->line('Schedule Item')),
            array('field' => 'customer_item_id', 'rules' => 'required', 'label' => $this->lang->line('Customer')),
            array('field' => 'start_date', 'rules' => 'required', 'label' => $this->lang->line('Start Date')),
            array('field' => 'end_date', 'rules' => 'required', 'label' => $this->lang->line('End Date')),
//            array('field'=>'description','rules'=>'required','label'=>$this->lang->line('Description'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }
        $this->load->view('schedule/schedule_add', array('result' => $this->schedule_actions->save_schedule()));
    }

    function delete_schedule($schedule_id) {
        $result = $this->schedule_actions->delete_schedule($schedule_id);
        die(json_encode($result));
    }

    function print_daily() {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');

        $data = $this->schedule_actions->get_schedule_daily();
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('schedule/daily_print', array('data' => $data, 'logo' => $logo), TRUE);
        //exit($html);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = "daily_schedule.pdf";

        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

    function find_employee() {
        $this->load->model('employees_actions');
        echo json_encode($this->employees_actions->search_employee());
    }

    function schedule_calendar() {
        $this->load->view('schedule/index');
    }

    function preview_schedule($schedule_id = 0) {
        $this->load->view('schedule/schedule_preview', array('schedule' => $this->schedule_actions->get_schedule($schedule_id)));
    }

    function print_schedule($schedule_id = 0) {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');

        $data = $this->schedule_actions->get_schedule($schedule_id);
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('schedule/schedule_print', array('data' => $data, 'logo' => $logo), TRUE);
        //exit($html);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = "schedule.pdf";

        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

}
