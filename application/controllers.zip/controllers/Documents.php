<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_record $db
 * @property CI_Session          $session
 * @property user_actions          $user_actions
 * @property documents_actions          $documents_actions
 */
class Documents extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('documents');
    }

    function index($page_id = 1) {
        $this->load->model('documents_actions');
        $this->load->helper('fa-extension');

        $this->load->view('documents/index', array(
            'documents' => $this->documents_actions->get_documents($page_id),
            'search' => $this->input->get('search')
        ));
    }

    function cat($document_category_id = 0, $page_id = 1) {
        $this->load->model('documents_actions');
        $this->load->helper('fa-extension');
        $category = $this->documents_actions->get_document_category($document_category_id);

        $this->load->view('documents/documents', array(
            'documents' => $this->documents_actions->get_cat_documents($document_category_id, $page_id),
            'active_menu' => $category['document_category_name'],
            'category_id' => $category['document_category_id'],
            'search' => $this->input->get('search')
        ));
    }

    function edit_document($document_id = 0) {
        $this->load->model('documents_actions');
        $this->load->helper('fa-extension');
        $this->load->model('attachments_actions');
        $this->load->view('documents/document_edit', array(
            'document' => $this->documents_actions->get_document($document_id),
            'attachments' => $this->attachments_actions->get_attachments($document_id, 'document')
        ));
    }

    function new_document($document_category_id = 0) {
        $this->load->view('documents/document_new', array('category_id' => $document_category_id));
    }

    function update_document() {
        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
        }
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'document_id', 'rules' => 'required', 'label' => 'document_id'),
            array('field' => 'document_category_id', 'rules' => 'required', 'label' => 'document_category_id'),
            array('field' => 'description', 'rules' => 'required', 'label' => 'description')
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('documents_actions');
        if (!$result = $this->documents_actions->save_document()) {
            exit($this->load->view('layout/error', array('message' => $this->documents_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('documents/document_add', $result);
    }

//    function update_document() {
//        $this->load->library('form_validation');
//        $this->form_validation->set_rules(array(
//            array('field' => 'document_id', 'rules' => 'required', 'label' => 'document_id'),
//            array('field' => 'document_category_id', 'rules' => 'required', 'label' => 'document_category_id')
//        ));
//
//        if ($this->form_validation->run() == FALSE) {
//            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
//        }
//
//        $this->load->model('documents_actions');
//        $result = $this->documents_actions->save_document();
//        if (!$result['result']) {
//            exit($this->load->view('layout/error', array('message' => $this->documents_actions->get_error()), TRUE));
//        }
//
//        $this->load->helper('fa-extension');
//        $this->load->view('documents/document_add', array('result' => $result));
//    }

    function download_document($document_id = 0) {
        $this->load->model('documents_actions');
        $this->documents_actions->download_document($document_id);
    }

    function delete_document() {
        $this->load->model('documents_actions');
        $this->documents_actions->delete_document($this->input->post('document_id'));
        $this->load->view('documents/document_delete', array('document_id' => $this->input->post('document_id')));
    }

    function find_employee() {
        $this->load->model('employees_actions');
        echo json_encode($this->employees_actions->search_employee());
    }

    function find_department() {
        $this->load->model('departments_actions');
        echo json_encode($this->departments_actions->search_department());
    }

    function find_position() {
        $this->load->model('positions_actions');
        echo json_encode($this->positions_actions->search_position());
    }

    function download_attachment($attachment_id = 0) {
        $this->load->model('attachments_actions');
        $this->attachments_actions->download_attachment($attachment_id);
    }

}
