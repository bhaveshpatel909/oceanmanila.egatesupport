<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_record $db
 * @property CI_Session          $session
 * @property discipline_actions          $discipline_actions
 */
class Discipline extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('discipline');
        $this->load->helper('url');
    }

    function index() {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/index', array('discipline' => $this->discipline_actions->get_records()));
    }

    function edit_record($record_id = 0) {
        $this->load->model('discipline_actions');
        $discipline_reasons = $this->discipline_actions->get_discipline_reasons();
        $discipline_actions = $this->discipline_actions->get_discipline_actions();
        $this->load->helper('fa-extension');
        $this->load->model('attachments_actions');
        $this->load->view(
                'discipline/record_edit', array('record' => $this->discipline_actions->get_record($record_id),
                    'attachments' => $this->attachments_actions->get_attachments($record_id, 'discipline'),
            'discipline_reasons' => $discipline_reasons,
            'discipline_actions' => $discipline_actions)
        );
    }

    function save_record() {
        $this->load->helper('fa-extension');
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'record_id', 'rules' => 'required', 'label' => 'record_id'),
            array('field' => 'employee_id[]', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'discipline_reason_id', 'rules' => 'required', 'label' => $this->lang->line('Reason')),
            array('field' => 'discipline_action_id', 'rules' => 'required', 'label' => $this->lang->line('Action')),
            array('field' => 'date', 'rules' => 'required', 'label' => $this->lang->line('Date')),
                //array('field'=>'description','rules'=>'required','label'=>$this->lang->line('Description'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('discipline_actions');
        if (!$result = $this->discipline_actions->save_record()) {
            exit($this->load->view('layout/error', array('message' => $this->discipline_actions->get_error()), TRUE));
        }
        $this->load->view('discipline/record_add', $result);
    }

    function delete_record() {
        $this->load->model('discipline_actions');
        $this->discipline_actions->delete_record($this->input->post('record_id'));
        $this->load->view('discipline/record_delete', array('record_id' => $this->input->post('record_id')));
    }

    function new_record() {
        $this->load->model('discipline_actions');
        $discipline_reasons = $this->discipline_actions->get_discipline_reasons();
        $discipline_actions = $this->discipline_actions->get_discipline_actions();
        $this->load->view('discipline/record_new', array('discipline_reasons' => $discipline_reasons, 'discipline_actions' => $discipline_actions));
    }

    function preview_record($record_id = 0) {
        $this->load->model('discipline_actions');
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $discipline = $this->discipline_actions->record_preview($record_id);
        //PDF generating
        $html = $this->load->view('discipline/record_preview', array('discipline' => $discipline, 'logo' => $logo), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = str_replace(" ", "_", $discipline['fullname']) . "_discipline.pdf";

        //load mPDF library
        $this->load->library('m_pdf');

        //generate the PDF from the given html
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

    function find_employee() {
        $this->load->model('employees_actions');
        echo json_encode($this->employees_actions->search_employee());
    }

    //Reasons

    function discipline_reasons() {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_reasons', array('discipline_reasons' => $this->discipline_actions->get_discipline_reasons()));
    }

    function new_discipline_reason() {
        $this->load->view('discipline/discipline_reason_new');
    }

    function get_discipline_reason() {
        $discipline_reason_id = $this->input->post('reason_id');
        $this->load->model('discipline_actions');
        $data = array('discipline_reason' => $this->discipline_actions->get_discipline_reason($discipline_reason_id));
        die(json_encode($data));
    }

    function edit_discipline_reason($discipline_reason_id = 0) {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_reason_edit', array('discipline_reason' => $this->discipline_actions->get_discipline_reason($discipline_reason_id)));
    }

    function save_discipline_reason() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'discipline_reason_id', 'rules' => 'required', 'label' => 'discipline_reason_id'),
            array('field' => 'discipline_reason_name', 'rules' => 'required', 'label' => $this->lang->line('discipline_reason_name')),
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_reason_add', array('result' => $this->discipline_actions->save_discipline_reason()));
    }

    function delete_discipline_reason() {
        $this->load->model('discipline_actions');
        $this->discipline_actions->delete_discipline_reason($this->input->post('discipline_reason_id'));
        $this->load->view('discipline/discipline_reason_delete', array('discipline_reason_id' => $this->input->post('discipline_reason_id')));
    }

    //Actions

    function discipline_actions() {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_actions', array('discipline_actions' => $this->discipline_actions->get_discipline_actions()));
    }

    function new_discipline_action() {
        $this->load->view('discipline/discipline_action_new');
    }

    function edit_discipline_action($discipline_action_id = 0) {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_action_edit', array('discipline_action' => $this->discipline_actions->get_discipline_action($discipline_action_id)));
    }

    function save_discipline_action() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'discipline_action_id', 'rules' => 'required', 'label' => 'discipline_action_id'),
            array('field' => 'discipline_action_name', 'rules' => 'required', 'label' => $this->lang->line('discipline_action_name')),
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('discipline_actions');
        $this->load->view('discipline/discipline_action_add', array('result' => $this->discipline_actions->save_discipline_action()));
    }

    function delete_discipline_action() {
        $this->load->model('discipline_actions');
        $this->discipline_actions->delete_discipline_action($this->input->post('discipline_action_id'));
        $this->load->view('discipline/discipline_action_delete', array('discipline_action_id' => $this->input->post('discipline_action_id')));
    }

    function discipline_reason_content() {
        
    }

    function company_rules() {
        $this->load->model('discipline_actions');
        $this->load->view('discipline/company_rules', array('company_rules' => $this->discipline_actions->get_company_rules()));
    }

    function print_company_rules() {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $this->load->model('discipline_actions');
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('discipline/company_rules_print', array('logo' => $logo, 'company_rules' => $this->discipline_actions->get_company_rules()), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = "company_rules.pdf";

        //load mPDF library
        $param = array(
            'mode' => 'en-GB-x',
            'format' => 'A4',
            'font_size' => 0,
            'font_default' => '',
            'margin_left' => 15,
            'margin_right' => 15,
            'margin_top' => 16,
            'margin_bottom' => 16,
            'margin_header' => 9,
            'margin_footer' => 9,
            'oriental' => 'P'
        );
        $this->load->library('m_pdf', $param);
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }
    
    function download_attachment($attachment_id = 0) {
        $this->load->model('attachments_actions');
        $this->attachments_actions->download_attachment($attachment_id);
    }

}
