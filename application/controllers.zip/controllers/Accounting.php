<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_record $db
 * @property CI_Session          $session
 * @property discipline_actions          $discipline_actions
 */
class Accounting extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('accounting');
        $this->load->helper('url');
    }

    function index() {
        
    }
    
    function bir_files() {        
        $this->load->model('accounting_actions');
        $this->load->view('accounting/bir_files', array('bir_files' => $this->accounting_actions->get_bir_files()));
    }
    
    function new_bir_file() {
        $this->load->model('settings_actions');
        $bir_forms = $this->settings_actions->get_bir_forms();
        //_custom_debug($bir_forms);
        $this->load->view('accounting/bir_file_new', array('bir_forms' => $bir_forms));
    }
    
    function edit_bir_file($bir_file_id = 0) {
        $this->load->model('settings_actions');
        $bir_forms = $this->settings_actions->get_bir_forms();
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');
        $this->load->model('accounting_actions');
        $bir_file = $this->accounting_actions->get_bir_file($bir_file_id);
        //_custom_debug($bir_file);
        $this->load->view('accounting/bir_file_edit',array(
            'bir_forms' => $bir_forms,
            'bir_file' => $bir_file,
            'attachments' => $this->attachments_actions->get_attachments($bir_file_id, 'bir_file')
                ));
    }
    
    function save_bir_file() {
        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
        }
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'form_id', 'rules' => 'required', 'label' => $this->lang->line('Form Name')),
            array('field' => 'amount', 'rules' => 'required', 'label' => $this->lang->line('Paid Amount')),
            array('field' => 'for_themonth', 'rules' => 'required', 'label' => $this->lang->line('For the month'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('accounting_actions');
        if (!$result = $this->accounting_actions->save_bir_file()) {
            exit($this->load->view('layout/error', array('message' => $this->accounting_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('accounting/bir_file_add', $result);
    }
    
    function delete_bir_file() {
        $this->load->model('accounting_actions');
        $this->accounting_actions->delete_bir_file($this->input->post('bir_file_id'));
        $this->load->view('accounting/bir_file_delete', array('bir_file_id' => $this->input->post('bir_file_id')));
    }

}
