<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_record $db
 * @property CI_Session          $session
 * @property user_actions          $user_actions
 * @property employees_actions          $employees_actions
 * @property mix_actions          $mix_actions
 * @property attachments_actions          $attachments_actions
 * @property positions_actions          $positions_actions
 */
class Employees extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('employees');
        $this->load->helper('url');
    }

    function index($page_id = 1) {
        $this->load->model('employees_actions');
        $this->load->view('employees/index', array(
            'employees' => $this->employees_actions->get_employees($page_id),
            'search' => $this->input->get('search'),
            'active_menu' => 'employees'
        ));
    }
    
    function inactive($page_id = 1) {
        $this->load->model('employees_actions');
        $this->load->view('employees/index', array(
            'employees' => $this->employees_actions->get_employees($page_id, FALSE),
            'search' => $this->input->get('search'),
            'active_menu' => 'inactive_employees'
        ));
    }

    function edit_employee($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('departments_actions');
        $this->load->model('positions_actions');
        $this->load->helper('fa-extension');
        $this->load->view('employees/employee_edit', array(
            'employee' => $this->employees_actions->get_employee($employee_id),
            'departments' => $this->departments_actions->get_departments(),
            'positions' => $this->positions_actions->get_positions(),
            'contracts' => $this->employees_actions->get_contract($employee_id),
            'licenses' => $this->employees_actions->get_licenses($employee_id)
        ));
    }

    function save_employee() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'employee_name', 'rules' => 'required', 'label' => $this->lang->line('Name')),
            array('field' => 'employee_email', 'rules' => 'required|valid_email', 'label' => $this->lang->line('Email'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');

        if (!$result = $this->employees_actions->save_employee()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->view('employees/employee_save', array(
            'result' => $result,
            'avatar' => $this->employees_actions->get_avatar()
        ));
    }

    function new_employe() {
        $this->load->view('employees/employee_new');
    }

    function save_address() {
        $this->load->model('employees_actions');
        $this->employees_actions->save_address();

        $this->load->view('layout/success', array('message' => $this->lang->line('Saved')));
    }

    function save_department() {
        $this->load->model('employees_actions');
        $this->employees_actions->save_department();

        $this->load->view('layout/success', array('message' => $this->lang->line('Saved')));
    }

    function save_position() {
        $this->load->model('employees_actions');
        $this->employees_actions->save_position();

        $this->load->view('layout/success', array('message' => $this->lang->line('Saved')));
    }

    function resign($employee_id = 0) {
        $this->load->model('mix_actions');
        $this->load->view('employees/employee_resign', array(
            'reasons' => $this->mix_actions->get_resign_reasons(),
            'employee_id' => $employee_id
        ));
    }

    function save_resign() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'reason', 'rules' => 'required', 'label' => $this->lang->line('Reason')),
            array('field' => 'date', 'rules' => 'required', 'label' => $this->lang->line('Date'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$this->employees_actions->resing_employee()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->view('employees/employee_resigned');
    }

    /**
     * Education
     * 
     */
    function education($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/education', array('education' => $this->employees_actions->get_education($employee_id)));
    }

    function edit_education($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');

        $this->load->view('employees/education_edit', array(
            'data' => $this->employees_actions->get_education_item($item_id),
            'attachments' => $this->attachments_actions->get_attachments($item_id, 'education')
        ));
    }

    function save_education() {
        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
        }

        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'education_id', 'rules' => 'required', 'label' => 'education_id'),
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'institution_name', 'rules' => 'required', 'label' => $this->lang->line('Institution')),
            array('field' => 'description', 'rules' => 'required', 'label' => $this->lang->line('Description'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');

        if (!$result = $this->employees_actions->save_education()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('employees/education_add', $result);
    }

    function new_education($employee_id = 0) {
        $this->load->view('employees/education_new', array('employee_id' => $employee_id));
    }

    function delete_education() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_education($this->input->post('education_id'));
        $this->load->view('employees/education_delete', array('education_id' => $this->input->post('education_id')));
    }

    /**
     * Department
     * 
     */
    function department($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/department', array('department' => $this->employees_actions->get_department($employee_id)));
    }

    function edit_department($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');

        $this->load->view('employees/department_edit', array(
            'data' => $this->employees_actions->get_department_item($item_id),
            'attachments' => $this->attachments_actions->get_attachments($item_id, 'department')
        ));
    }

//    function save_department() {
//        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
//            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
//        }
//
//        $this->load->library('form_validation');
//        $this->form_validation->set_rules(array(
//            array('field' => 'department_id', 'rules' => 'required', 'label' => 'department_id'),
//            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
//            array('field' => 'institution_name', 'rules' => 'required', 'label' => $this->lang->line('Institution')),
//            array('field' => 'description', 'rules' => 'required', 'label' => $this->lang->line('Description'))
//        ));
//
//        if ($this->form_validation->run() == FALSE) {
//            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
//        }
//
//        $this->load->model('employees_actions');
//
//        if (!$result = $this->employees_actions->save_department()) {
//            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
//        }
//
//        $this->load->helper('fa-extension');
//        $this->load->view('employees/department_add', $result);
//    }

    function new_department($employee_id = 0) {
        $this->load->view('employees/department_new', array('employee_id' => $employee_id));
    }

    function delete_department() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_department($this->input->post('department_id'));
        $this->load->view('employees/department_delete', array('department_id' => $this->input->post('department_id')));
    }

    function positions($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/positions', array('positions' => $this->employees_actions->get_positions($employee_id)));
    }

    function position_edit($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/position_edit', array('position' => $this->employees_actions->get_position($item_id)));
    }

    function update_position() {
        $this->load->model('employees_actions');
        $this->employees_actions->update_position();
        $this->load->view('layout/success', array('message' => $this->lang->line('Updated')));
    }

    function position_view($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/position_view', array('position' => $this->employees_actions->get_position($item_id)));
    }

    function new_position($employee_id = 0) {
        $this->load->model('positions_actions');
        $this->load->model('employees_actions');

        $this->load->view('employees/position_new', array(
            'positions' => $this->positions_actions->get_grouped_positions(),
            'employee_id' => $employee_id,
            'current_position' => $this->employees_actions->get_current_position($employee_id)
        ));
    }

//    function save_position() {
//        //_custom_debug($this->input->post());
//        $this->load->library('form_validation');
//        $this->form_validation->set_rules(array(
//            array('field' => 'new_position', 'rules' => 'required', 'label' => $this->lang->line('New position')),
//            array('field' => 'start_date', 'rules' => 'required', 'label' => $this->lang->line('Start date')),
//            array('field' => 'move_reason', 'rules' => 'required', 'label' => $this->lang->line('Move reason'))
//        ));
//
//        if ($this->form_validation->run() == FALSE) {
//            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
//        }
//
//        $this->load->model('employees_actions');
//        if (!$this->employees_actions->add_position()) {
//            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
//        }
//
//        $this->load->view('employees/position_add');
//    }

    function check_position($position_id = 0, $employee_id = 0) {
        $this->load->model('positions_actions');
        $this->load->view('employees/position_compatible', array('data' => $this->positions_actions->check_position($position_id, $employee_id)));
    }

    function skills($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/skills', array('skills' => $this->employees_actions->get_skills($employee_id)));
    }

    function edit_skills($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/skills_edit', array(
            'skills' => $this->employees_actions->get_employee_skills($employee_id),
            'employee_id' => $employee_id
        ));
    }

    function save_skills() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id')
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$result = $this->employees_actions->save_employee_skills()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->view('employees/skills_add', array('result' => $result));
    }

    function employment($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/employment', array('employment' => $this->employees_actions->get_employment($employee_id)));
    }

    function edit_employment($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/employment_edit', array('employment' => $this->employees_actions->get_employment_item($item_id)));
    }

    function save_employment() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'employment_id', 'rules' => 'required', 'label' => 'employment_id'),
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'company', 'rules' => 'required', 'label' => $this->lang->line('Company')),
            array('field' => 'position', 'rules' => 'required', 'label' => $this->lang->line('Position')),
            array('field' => 'start', 'rules' => 'required', 'label' => $this->lang->line('Start')),
            array('field' => 'end', 'rules' => 'required', 'label' => $this->lang->line('End'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$result = $this->employees_actions->save_employment()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->view('employees/employment_add', array('result' => $result));
    }

    function new_employment($employee_id = 0) {
        $this->load->view('employees/employment_new', array('employee_id' => $employee_id));
    }

    function delete_employment() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_employment($this->input->post('employment_id'));
        $this->load->view('employees/employment_delete', array('employment_id' => $this->input->post('employment_id')));
    }

    function relatives($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/family', array('family' => $this->employees_actions->get_family($employee_id)));
    }

    function edit_relative($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');

        $this->load->view('employees/relative_edit', array(
            'relative' => $this->employees_actions->get_relative($item_id),
            'attachments' => $this->attachments_actions->get_attachments($item_id, 'relative')
        ));
    }

    function save_relative() {
        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
        }

        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'relative_id', 'rules' => 'required', 'label' => 'relative_id'),
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'relative_name', 'rules' => 'required', 'label' => $this->lang->line('Name'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$result = $this->employees_actions->save_relative()) {
            exit($this->load->view('layout/error', array('error' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('employees/relative_add', $result);
    }

    function delete_relative() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_relative($this->input->post('relative_id'));
        $this->load->view('employees/relative_delete', array('relative_id' => $this->input->post('relative_id')));
    }

    function new_relative($employee_id = 0) {
        $this->load->view('employees/relative_new', array('employee_id' => $employee_id));
    }

    function licenses($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/licenses', array('licenses' => $this->employees_actions->get_licenses($employee_id)));
    }

    function edit_license($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');

        $this->load->view('employees/license_edit', array(
            'license' => $this->employees_actions->get_license($item_id),
            'attachments' => $this->attachments_actions->get_attachments($item_id, 'license')
        ));
    }

    function save_license() {
        if ((count($_POST) == 0) AND ( count($_FILES) == 0)) {
            exit($this->load->view('layout/error', array('message' => $this->lang->line('Too many files')), TRUE));
        }

        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'license_id', 'rules' => 'required', 'label' => 'license_id'),
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'license_name', 'rules' => 'required', 'label' => $this->lang->line('Name')),
            array('field' => 'expiry', 'rules' => 'required', 'label' => $this->lang->line('Expiry')),
            array('field' => 'license_number', 'rules' => 'required', 'label' => $this->lang->line('Number'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$result = $this->employees_actions->save_license()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('employees/license_add', $result);
    }

    function delete_license() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_license($this->input->post('license_id'));
        $this->load->view('employees/license_delete', array('license_id' => $this->input->post('license_id')));
    }

    function new_license($employee_id = 0) {
        $this->load->view('employees/license_new', array('employee_id' => $employee_id));
    }

    function remove_attachment($attachment_id = 0) {
        $this->load->model('attachments_actions');
        $this->attachments_actions->remove_attachment($attachment_id);
    }

    function download_attachment($attachment_id = 0) {
        $this->load->model('attachments_actions');
        $this->attachments_actions->download_attachment($attachment_id);
    }

    function set_password($employee_id = 0) {
		$userdata = $this->session->userdata();
        if ((($employee_id == '1') && $userdata['employee_id'] != '1') OR ( !$this->user_actions->is_allowed('admin'))) {
            return FALSE;
        }

        $this->load->view('employees/password_set', array(
            'is_active' => $this->user_actions->is_employee_active($employee_id),
            'employee_id' => $employee_id,
            'permissions' => $this->user_actions->get_permissions($employee_id)
        ));
    }

    function save_password() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id')
        ));

        if ($this->input->post('new_password')) {
            $this->form_validation->set_rules(array(
                array('field' => 'new_password', 'rules' => 'required', 'label' => $this->lang->line('New password')),
                array('field' => 'password_again', 'rules' => 'required', 'label' => $this->lang->line('Password again'))
            ));
        }

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/success', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->user_actions->update_password();
        $this->load->view('layout/success', array('message' => $this->lang->line('Done')));
    }

    function contract_type() {
        $this->load->model('contract_type');
        $this->load->view('employees/contract_type_list', array('contract_types' => $this->contract_type->get_contract_type_list()));
    }

    function new_contract_type() {
        $this->load->view('employees/contract_type_new');
    }

    function get_contract_type() {
        $contract_type_id = $this->input->post('id');
        $this->load->model('contract_type');
        $data = array('contract_type' => $this->contract_type->get_contract_type($contract_type_id));
        die(json_encode($data));
    }

    function edit_contract_type($contract_type_id = 0) {
        $this->load->model('contract_type');
        $this->load->view('employees/contract_type_edit', array('contract_type' => $this->contract_type->get_contract_type($contract_type_id)));
    }

    function save_contract_type() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'contract_type_id', 'rules' => 'required', 'label' => 'contract_type_id'),
            array('field' => 'contract_type_name', 'rules' => 'required', 'label' => $this->lang->line('contract_type_name')),
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('contract_type');
        $this->load->view('employees/contract_type_add', array('result' => $this->contract_type->save_contract_type()));
    }

    function delete_contract_type() {
        $this->load->model('contract_type');
        $this->contract_type->delete_contract_type($this->input->post('contract_type_id'));
        $this->load->view('employees/contract_type_delete', array('contract_type_id' => $this->input->post('contract_type_id')));
    }

    function contract($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->view('employees/contract', array('contracts' => $this->employees_actions->get_contract($employee_id)));
    }

    function edit_contract($item_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('contract_type');
        $this->load->model('attachments_actions');
        $this->load->helper('fa-extension');
        $contract_types = $this->contract_type->get_contract_type_list();
        $this->load->view('employees/contract_edit', array(
            'contract' => $this->employees_actions->get_contract_item($item_id),
            'contract_types' => $contract_types,
            'attachments' => $this->attachments_actions->get_attachments($item_id, 'contract')
        ));
    }

    function save_contract() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'contract_id', 'rules' => 'required', 'label' => 'contract_id'),
            array('field' => 'employee_id', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'contract_type_id', 'rules' => 'required', 'label' => 'contract_type_id'),
            array('field' => 'content', 'rules' => 'required', 'label' => $this->lang->line('Contract Content')),
            array('field' => 'contract_condition', 'rules' => 'required', 'label' => $this->lang->line('Contract Condition')),
            array('field' => 'contract_expiry', 'rules' => 'required', 'label' => $this->lang->line('Contract Expiration Date'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('employees_actions');
        if (!$result = $this->employees_actions->save_contract()) {
            exit($this->load->view('layout/error', array('message' => $this->employees_actions->get_error()), TRUE));
        }

        $this->load->helper('fa-extension');
        $this->load->view('employees/contract_add', $result);

        //$this->load->view('employees/contract_add', array('result' => $result));
    }

    function new_contract($employee_id = 0) {
        $this->load->model('contract_type');
        $contract_types = $this->contract_type->get_contract_type_list();
        $this->load->view('employees/contract_new', array('employee_id' => $employee_id, 'contract_types' => $contract_types));
    }

    function delete_contract() {
        $this->load->model('employees_actions');
        $this->employees_actions->delete_contract($this->input->post('contract_id'));
        $this->load->view('employees/contract_delete', array('contract_id' => $this->input->post('contract_id')));
    }

    function print_contract($contract_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $contract = $this->employees_actions->print_contract($contract_id);
        //PDF generating
        $html = $this->load->view('employees/contract_print', array('contract' => $contract, 'logo' => $logo), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = str_replace(" ", "_", $contract['fullname']) . "_contract.pdf";

        //load mPDF library
        $this->load->library('m_pdf');

        //generate the PDF from the given html
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

    function print_employee($employee_id = 0) {
        $this->load->model('employees_actions');
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $company_name = $this->settings_actions->get_setting('company_name');
        $company_address = $this->settings_actions->get_setting('company_address');
        $employee = $this->employees_actions->print_employee($employee_id);

        $data = array(
            'company' => array('logo' => $logo, 'name' => $company_name, 'address' => $company_address),
            'employee' => $employee
        );
        //PDF generating
        $html = $this->load->view('employees/employee_print', $data, TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = str_replace(" ", "_", $employee['fullname']) . "_employee.pdf";

        //load mPDF library
        $param = array(
            'mode' => 'en-GB-x',
            'format' => 'A4',
            'font_size' => 0,
            'font_default' => '',
            'margin_left' => 15,
            'margin_right' => 15,
            'margin_top' => 16,
            'margin_bottom' => 16,
            'margin_header' => 9,
            'margin_footer' => 9,
            'oriental' => 'P'
        );
        $this->load->library('m_pdf', $param);
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

    function upload_avatar() {
        //_custom_debug($_FILES);
        $employee_id = $this->input->get('employee_id');
        if (isset($_FILES['webcam']) AND ( $_FILES['webcam']['error'] == 0)) {
            $this->load->library('upload', array('upload_path' => BASEPATH . '../files/avatars/', 'allowed_types' => 'gif|jpg|jpeg|png', 'max_size' => '300', 'encrypt_name' => TRUE));

            if (!$this->upload->do_upload('webcam')) {
                $this->set_error($this->upload->display_errors());
                return FALSE;
            }

            $this->load->library('image_lib', array('image_library' => 'gd2', 'source_image' => $this->upload->upload_path . $this->upload->file_name, 'maintain_ratio' => FALSE, 'width' => 140, 'height' => 140, 'master_dim' => 'height'));

            if (!$this->image_lib->resize()) {
                $this->set_error($this->image_lib->display_errors());
                return FALSE;
            }

            $avatar = 'files/avatars/' . $this->upload->file_name;
            //_custom_debug($avatar);
            $this->load->model('employees_actions');
            $this->employees_actions->update_employee_avatar($employee_id,$avatar);
        }
    }

}
