<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_record $db
 * @property CI_Session          $session
 * @property user_actions          $user_actions
 * @property employees_actions          $employees_actions
 * @property mix_actions          $mix_actions
 * @property attachments_actions          $attachments_actions
 * @property positions_actions          $positions_actions
 * @property departments_actions          $departments_actions
 * @property reports_actions          $reports_actions
 */
class Reports extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('reports');
        $this->load->helper('url');
    }

    function index() {
        
    }

    function skills() {
        $this->load->model('departments_actions');
        $this->load->view('reports/skills/index', array(
            'departments' => $this->departments_actions->get_departments_list()
        ));
    }

    function get_departments() {
        $this->load->model('departments_actions');
        $this->load->view('reports/departments', array(
            'departments' => $this->departments_actions->get_departments_list()
        ));
    }

    function proccess_report() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'report_category', 'rules' => 'required', 'label' => 'report_category'),
            array('field' => 'report_type', 'rules' => 'required', 'label' => 'report_type'),
            array('field' => 'start_date', 'rules' => 'required', 'label' => $this->lang->line('Start date')),
            array('field' => 'end_date', 'rules' => 'required', 'label' => $this->lang->line('End date'))
        ));

        $this->load->model('reports_actions');
        $this->reports_actions->validate_fields();

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }
        $postData = $this->input->post();

        $this->load->view('reports/' . $this->input->post('report_category') . '/' . $this->input->post('report_type'), array('data' => $this->reports_actions->get_results(), 'postdata' => json_encode($postData)));
    }

    function clock() {
        $this->load->view('reports/clock/index');
    }
    
    function discipline() {
        $this->load->view('reports/discipline/index');
    }

    function find_employee() {
        $this->load->model('employees_actions');
        echo json_encode($this->employees_actions->search_employee());
    }
    
    function print_report() {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $json = $this->input->post('jsondata');
        //_custom_debug(json_decode($json, true));
        $_POST = json_decode($json, true);
        $this->load->model('reports_actions');
        $data = $this->reports_actions->print_discipline_report();
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('reports/discipline/print', array('data' => $data,'logo' => $logo, 'from' => $_POST['start_date'], 'to' => $_POST['end_date']), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = str_replace(" ", "_", $data[0]['fullname']) . "_report.pdf";

        //load mPDF library
        $param = array(
            'mode' => 'en-GB-x',
            'format' => 'A4',
            'font_size' =>  0,
            'font_default' => '',
            'margin_left' => 15,
            'margin_right' => 15,
            'margin_top' => 16,
            'margin_bottom' => 16,
            'margin_header' => 9,
            'margin_footer' => 9,
            'oriental' => 'P'
        );
        $this->load->library('m_pdf',$param);
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }
    
    function print_punch_clock() {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $json = $this->input->post('jsondata');
        //_custom_debug(json_decode($json, true));
        $_POST = json_decode($json, true);
        $this->load->model('reports_actions');
        $data = $this->reports_actions->print_punch_clock();
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('reports/clock/print', array('data' => $data,'logo' => $logo, 'from' => $_POST['start_date'], 'to' => $_POST['end_date']), TRUE);
        //exit($html);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = "punch_clock_report.pdf";

        //load mPDF library
        $param = array(
            'mode' => 'en-GB-x',
            'format' => 'A4',
            'font_size' =>  0,
            'font_default' => '',
            'margin_left' => 15,
            'margin_right' => 15,
            'margin_top' => 16,
            'margin_bottom' => 16,
            'margin_header' => 9,
            'margin_footer' => 9,
            'oriental' => 'P'
        );
        $this->load->library('m_pdf',$param);
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }
    
    function work_evaluation_rules() {
        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/company_rules', array('company_rules' => $this->evaluation_actions->get_company_rules()));
    }

    function print_work_evaluation_rules() {
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $this->load->model('evaluation_actions');
        //_custom_debug($data);
        //PDF generating
        $html = $this->load->view('evaluation/company_rules_print', array('logo' => $logo, 'company_rules' => $this->evaluation_actions->get_company_rules()), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = "work_evaluation_rules.pdf";

        //load mPDF library
        $param = array(
            'mode' => 'en-GB-x',
            'format' => 'A4',
            'font_size' => 0,
            'font_default' => '',
            'margin_left' => 15,
            'margin_right' => 15,
            'margin_top' => 16,
            'margin_bottom' => 16,
            'margin_header' => 9,
            'margin_footer' => 9,
            'oriental' => 'P'
        );
        $this->load->library('m_pdf', $param);
        $this->m_pdf->pdf->WriteHTML($html);

        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I");
    }

}
