<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_active_evaluation $db
 * @property CI_Session          $session
 * @property evaluation_actions          $evaluation_actions
 */
class Evaluation extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('user_actions');
        $this->user_actions->is_loged_in('evaluations');
        $this->load->helper('url');
    }

    function index() {
        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/index', array('evaluations' => $this->evaluation_actions->get_evaluations()));
    }

    function edit_evaluation($evaluation_id = 0) {
        $this->load->model('evaluation_actions');
        $evaluation_templates = $this->evaluation_actions->get_evaluation_templates();
        $this->load->view('evaluation/evaluation_edit', array('evaluation' => $this->evaluation_actions->get_evaluation($evaluation_id), 'evaluation_templates' => $evaluation_templates));
    }

    function save_evaluation() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'evaluation_id', 'rules' => 'required', 'label' => 'evaluation_id'),
            array('field' => 'employee_id[]', 'rules' => 'required', 'label' => 'employee_id'),
            array('field' => 'evaluation_template_id', 'rules' => 'required', 'label' => $this->lang->line('Evaluation Name')),
            array('field' => 'date', 'rules' => 'required', 'label' => $this->lang->line('Date')),
                //array('field'=>'description','rules'=>'required','label'=>$this->lang->line('Description'))
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/evaluation_add', array('result' => $this->evaluation_actions->save_evaluation()));
    }

    function delete_evaluation() {
        $this->load->model('evaluation_actions');
        $this->evaluation_actions->delete_evaluation($this->input->post('evaluation_id'));
        $this->load->view('evaluation/evaluation_delete', array('evaluation_id' => $this->input->post('evaluation_id')));
    }

    function new_evaluation() {
        $this->load->model('evaluation_actions');
        $evaluation_templates = $this->evaluation_actions->get_evaluation_templates();
        $this->load->view('evaluation/evaluation_new', array('evaluation_templates' => $evaluation_templates));
    }

    function preview_evaluation($evaluation_id = 0) {
        $this->load->model('evaluation_actions');
        $this->load->model('settings_actions');
        $logo = $this->settings_actions->get_setting('company_logo');
        $evaluation = $this->evaluation_actions->evaluation_preview($evaluation_id);
        //PDF generating
        $html = $this->load->view('evaluation/evaluation_preview', array('evaluation' => $evaluation, 'logo' => $logo), TRUE);
        ini_set('memory_limit', '32M'); // boost the memory limit if it's low <img src="https://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" draggable="false" class="emoji">
        //this the the PDF filename that user will get to download
        $pdfFilePath = str_replace(" ", "_", $evaluation['fullname']) . "_evaluation.pdf";
 
        //load mPDF library
        $this->load->library('m_pdf');
 
       //generate the PDF from the given html
        $this->m_pdf->pdf->WriteHTML($html);
 
        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "I"); 
    }

    function find_employee() {
        $this->load->model('employees_actions');
        echo json_encode($this->employees_actions->search_employee());
    }

    //Reasons

    function evaluation_templates() {
        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/evaluation_templates', array('evaluation_templates' => $this->evaluation_actions->get_evaluation_templates()));
    }

    function new_evaluation_template() {
        $this->load->view('evaluation/evaluation_template_new');
    }

    function get_evaluation_template() {
        $evaluation_template_id = $this->input->post('reason_id');
        $this->load->model('evaluation_actions');
        $data = array('evaluation_template' => $this->evaluation_actions->get_evaluation_template($evaluation_template_id));
        die(json_encode($data));
    }

    function edit_evaluation_template($evaluation_template_id = 0) {
        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/evaluation_template_edit', array('evaluation_template' => $this->evaluation_actions->get_evaluation_template($evaluation_template_id)));
    }

    function save_evaluation_template() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'evaluation_template_id', 'rules' => 'required', 'label' => 'evaluation_template_id'),
            array('field' => 'evaluation_template_name', 'rules' => 'required', 'label' => $this->lang->line('evaluation_template_name')),
        ));

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }

        $this->load->model('evaluation_actions');
        $this->load->view('evaluation/evaluation_template_add', array('result' => $this->evaluation_actions->save_evaluation_template()));
    }

    function delete_evaluation_template() {
        $this->load->model('evaluation_actions');
        $this->evaluation_actions->delete_evaluation_template($this->input->post('evaluation_template_id'));
        $this->load->view('evaluation/evaluation_template_delete', array('evaluation_template_id' => $this->input->post('evaluation_template_id')));
    }
    
    function employee_evaluation() {
        $this->load->view('reports/evaluation/index');
    }

    function report_evaluation() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules(array(
            array('field' => 'report_category', 'rules' => 'required', 'label' => 'report_category'),
            array('field' => 'report_type', 'rules' => 'required', 'label' => 'report_type'),
            array('field' => 'start_date', 'rules' => 'required', 'label' => $this->lang->line('Start date')),
            array('field' => 'end_date', 'rules' => 'required', 'label' => $this->lang->line('End date'))
        ));

        $this->load->model('evaluation_actions');
        $this->evaluation_actions->validate_fields();

        if ($this->form_validation->run() == FALSE) {
            exit($this->load->view('layout/error', array('message' => $this->form_validation->error_string()), TRUE));
        }
        $postData = $this->input->post();
        //_custom_debug($this->evaluation_actions->get_evaluation_report());
        $this->load->view('reports/' . $this->input->post('report_category') . '/' . $this->input->post('report_type'), array('data' => $this->evaluation_actions->get_evaluation_report(), 'postdata' => json_encode($postData)));
    }

}