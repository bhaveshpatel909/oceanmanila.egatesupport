<?php

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_query_builder $db
 * @property CI_Session          $session
 */
class Reports_actions extends Base_model {

    function get_results() {
        return call_user_func(array($this, $this->input->post('report_category') . '_' . $this->input->post('report_type')));
    }

    function validate_fields() {
        switch ($this->input->post('report_category') . '_' . $this->input->post('report_type')) {
            
        }
    }

    function get_newly_hired() {
        return $this->db
                        ->select('name,avatar, position_name, department_name, hired_at,vacancies_applicants.employee_id')
                        ->join('employees', 'employees.employee_id = vacancies_applicants.employee_id', 'LEFT')
                        ->join('employees_positions', 'employees_positions.employee_id  = employees.employee_id AND employees_positions.is_current=1', 'LEFT')
                        ->join('positions', 'positions.position_id = employees_positions.position_id', 'LEFT')
                        ->join('departments', 'departments.department_id = positions.department_id', 'LEFT')
                        ->where('vacancies_applicants.status', 'Enrolled')
                        ->limit(5)
                        ->order_by('vacancies_applicants.employee_id', 'DESC')
                        ->get('vacancies_applicants')
                        ->result_array();
    }

    function get_last_discipline() {
        return $this->db
                        ->select('discipline.*, employees.name as fullname, employees.avatar,employees.position_id, employees.department_id, positions.position_name, departments.department_name,discipline_reasons.name as reason_name, discipline_reasons.content as reason_content, discipline_actions.name as action_name')
                        ->join('employees', 'employees.employee_id = discipline.employee_id', 'LEFT')
                        ->join('positions', 'positions.position_id = employees.position_id', 'LEFT')
                        ->join('departments', 'departments.department_id = employees.department_id', 'LEFT')
                        ->join('discipline_reasons', 'discipline_reasons.id = discipline.discipline_reason_id', 'LEFT')
                        ->join('discipline_actions', 'discipline_actions.id = discipline.discipline_action_id', 'LEFT')
                        ->limit(5)
                        ->order_by('discipline.date DESC')
                        ->get('discipline')
                        ->result_array();
    }

    function clock_default() {
        if (isset($_POST['employee'])) {
            $this->db->where('punch_clock.employee_id', (int) $_POST['employee'][0]);
        } else {
            $this->db
                    ->select('employees.employee_id,name, position_name, department_name, avatar')
                    ->join('employees', 'employees.employee_id = punch_clock.employee_id', 'LEFT')
                    ->join('employees_positions', 'employees_positions.employee_id = punch_clock.employee_id AND employees_positions.is_current=1', 'LEFT')
                    ->join('positions', 'positions.position_id = employees_positions.position_id', 'LEFT')
                    ->join('departments', 'departments.department_id = employees.department_id', 'LEFT');
        }

        $result = $this->db
                        ->select('start_time,end_time, DATE_FORMAT(start_time,"%Y%m%d") as date_id, comments')
                        ->where(array('start_time >= ' => date('Y-m-d 00:00:00', strtotime($this->input->post('start_date'))), 'start_time <= ' => date('Y-m-d 23:59:59', strtotime($this->input->post('end_date')))))
                        ->order_by('start_time')
                        ->get('punch_clock')        
                        ->result_array();
        array_sort_by_column($result, 'employee_id');
        return $result;
    }

    function discipline_discipline() {
        $employee = $this->input->post('employee');
        if (isset($employee)) {
            $this->db->where('discipline.employee_id', (int) $employee[0]);
        } else {
            $this->db
                    ->select('employees.name as fullname')
                    ->join('employees', 'employees.employee_id = discipline.employee_id', 'LEFT');
        }

        $query = $this->db
                ->select('discipline.record_id, discipline.date, discipline_reasons.name as reason, discipline_actions.name as action_taken, discipline_actions.score')
                //->join('employees', 'employees.employee_id = discipline.employee_id', 'LEFT')
                ->join('discipline_reasons', 'discipline_reasons.id = discipline.discipline_reason_id', 'LEFT')
                ->join('discipline_actions', 'discipline_actions.id = discipline.discipline_action_id', 'LEFT')
                ->where(array('date >= ' => date('Y-m-d', strtotime($this->input->post('start_date'))), 'date <= ' => date('Y-m-d', strtotime($this->input->post('end_date')))))
                ->order_by('date')
                ->get('discipline');
        //die($this->db->last_query());
        return $query->result_array();
    }

    function print_discipline_report() {
        $employee = $this->input->post('employee');
        if (isset($employee)) {
            $this->db->where('discipline.employee_id', (int) $employee[0]);
        }
        $this->db
                ->select('employees.name as fullname')
                ->join('employees', 'employees.employee_id = discipline.employee_id', 'LEFT');
        $query = $this->db
                ->select('discipline.record_id, discipline.date, discipline_reasons.name as reason, discipline_actions.name as action_taken, discipline_actions.score')
                ->join('discipline_reasons', 'discipline_reasons.id = discipline.discipline_reason_id', 'LEFT')
                ->join('discipline_actions', 'discipline_actions.id = discipline.discipline_action_id', 'LEFT')
                ->where(array('date >= ' => date('Y-m-d', strtotime($this->input->post('start_date'))), 'date <= ' => date('Y-m-d', strtotime($this->input->post('end_date')))))
                ->order_by('date')
                ->get('discipline');
        //die($this->db->last_query());
        return $query->result_array();
    }

    function print_punch_clock() {
        $employee = $this->input->post('employee');
        if (isset($employee)) {
            $this->db->where('punch_clock.employee_id', (int) $employee[0]);
        }
        $this->db
                ->select('employees.employee_id, employees.name as fullname, position_name, department_name, avatar')
                ->join('employees', 'employees.employee_id = punch_clock.employee_id', 'LEFT')
                ->join('positions', 'positions.position_id = employees.position_id', 'LEFT')
                ->join('departments', 'departments.department_id = employees.department_id', 'LEFT');
        $query = $this->db
                ->select('start_time,end_time, DATE_FORMAT(start_time,"%Y%m%d") as date_id, comments')
                ->where(array('start_time >= ' => date('Y-m-d 00:00:00', strtotime($this->input->post('start_date'))), 'start_time <= ' => date('Y-m-d 23:59:59', strtotime($this->input->post('end_date')))))
                ->order_by('start_time')
                ->get('punch_clock');
        //die($this->db->last_query());
        $result = $query->result_array();
        array_sort_by_column($result, 'employee_id');
//        _custom_debug($result);
        return $result;
        
    }

}
