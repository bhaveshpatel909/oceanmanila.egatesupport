<?php

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_query_builder $db
 * @property CI_Session          $session
 * @property attachments_actions          $attachments_actions
 * @property departments_actions          $departments_actions
 * @property user_actions          $user_actions
 */
class Task_actions extends Base_model {

    public function __construct() {
        parent::__construct();
    }

    public function get_task_status_list() {
        return $this->db
                        ->select('*')
                        ->get('task_status')
                        ->result_array();
    }

    function get_task_status($task_status_id) {
        $this->db->select('*');
        $this->db->where('task_status_id', $task_status_id);
        $query = $this->db->get('task_status');
        return $query->row_array();
    }

    function save_task_status() {
        $data = array(
            'task_status_name' => $this->input->post('task_status_name'),
//            'description' => $this->input->post('description')
        );

        if ($this->input->post('task_status_id') == '0') {
            $this->db->insert('task_status', $data);
            return $this->db->insert_id();
        }

        $this->db->update('task_status', $data, array('task_status_id' => $this->input->post('task_status_id')));
        return TRUE;
    }

    function delete_task_status($task_status_id) {
        $this->db->delete('task_status', array('task_status_id' => $task_status_id));
    }

    public function get_task_category_list() {
        return $this->db
                        ->select('*')
                        ->get('task_category')
                        ->result_array();
    }

    function get_task_category($task_category_id) {
        $this->db->select('*');
        $this->db->where('task_category_id', $task_category_id);
        $query = $this->db->get('task_category');
        return $query->row_array();
    }

    function save_task_category() {
        $data = array(
            'task_category_name' => $this->input->post('task_category_name'),
//            'description' => $this->input->post('description')
        );

        if ($this->input->post('task_category_id') == '0') {
            $this->db->insert('task_category', $data);
            return $this->db->insert_id();
        }

        $this->db->update('task_category', $data, array('task_category_id' => $this->input->post('task_category_id')));
        return TRUE;
    }

    function delete_task_category($task_category_id) {
        $this->db->delete('task_category', array('task_category_id' => $task_category_id));
    }

    public function get_tasks($status = null, $employee_id = null) {
        if (isset($status)) {
            if ($status == 'all') {
                $this->db->where(array('tasks.status !=' => 'completed'));
            } elseif($status == 'regular') {
                $this->db->where(array('tasks.task_regular' => 1));
            } else {
                $this->db->where(array('tasks.status' => $status));
            }
        }
        if (isset($employee_id)) {
            $this->db->where(array('tasks.employee_id' => $employee_id));
        }
        $this->db->order_by('updated_date','desc');
        $query = $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name ')
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT')
                ->get('tasks');
        //die($this->db->last_query());
        $result = $query->result_array();
        return $result;
    }

    public function get_attention_tasks($employee_id = null) {
        if (isset($employee_id)) {
            $this->db->where(array('tasks.employee_id' => $employee_id));
        }
        $this->db->where(array('tasks.task_attention ' => 'required', 'tasks.employee_id !=' => ''));
        $this->db->order_by('updated_date','desc');
        $query = $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name ')
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT')
                ->get('tasks');
        //die($this->db->last_query());
        $result = $query->result_array();        return $result;
    }

    public function get_attention_updated_tasks($employee_id = null) {
        if (isset($employee_id)) {
            $this->db->where(array('tasks.employee_id' => $employee_id));
        }
        $this->db->where(array('tasks.task_attention ' => 'updated', 'tasks.employee_id !=' => ''));
        $this->db->order_by('updated_date','desc');
        $query = $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name ')
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT')
                ->get('tasks');
        //die($this->db->last_query());
        $result = $query->result_array();
        return $result;
    }

    public function get_completed_tasks($employee_id = null) {
        $this->db->where(array('tasks.process' => 100));
        if (isset($employee_id)) {
            $this->db->where(array('tasks.employee_id' => $employee_id));
        }
        $this->db->order_by('updated_date','desc');
        $query = $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name ')
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT')
                ->get('tasks');
        //die($this->db->last_query());
        $result = $query->result_array();
        return $result;
    }

    function get_task($task_id) {
        $this->db->where('task_id', $task_id);
        $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name, CONCAT(employees.name," [",IFNULL(departments.department_name,"-"),"] ", IFNULL(positions.position_name,"-")) as employee_name', FALSE)
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('positions', 'positions.position_id = employees.position_id', 'LEFT')
                ->join('departments', 'departments.department_id = employees.department_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT');
        $query = $this->db->get('tasks');
        return $query->row_array();
    }

    function save_task() {
        $data = array(
            'task_title' => $this->input->post('task_title'),
            'status' => $this->input->post('task_status'),
            'task_attention' => $this->input->post('task_attention'),
            'task_regular' => $this->input->post('task_regular'),
            'task_category_id' => $this->input->post('task_category_id'),
            'start_date' => $this->input->post('start_date'),
            'due_date' => $this->input->post('due_date'),
            'description' => $this->input->post('description'),
            'additional' => $this->input->post('additional')
        );

        $employee_id = $this->input->post('employee_id');
        $data['employee_id'] = $employee_id[0];
//        if (isset($data['employee_id'])) {
//            $data['status'] = 'assigned';
//        } else {
//            $data['status'] = 'unassigned';
//        }
        //_custom_debug( $this->input->post());

        if ($this->input->post('task_id') == '0') {

            $this->db->insert('tasks', $data);
            $result = $task_id = $this->db->insert_id();
        } else {
            $data['updated_date'] = date('Y-m-d H:i:s');
            $this->db->update('tasks', $data, array('task_id' => $this->input->post('task_id')));
            $result = TRUE;
            $task_id = $this->input->post('task_id');
        }


        $this->load->model('attachments_actions');
        if (!$files = $this->attachments_actions->upload_attachments('task', $task_id)) {
            return FALSE;
        }

        return array_merge($files, array('result' => $result));
    }

    function delete_task($task_id) {
        $this->db->delete('task_log', array('task_id' => $task_id));
        $this->db->delete('attachments', array('object' => $task_id, 'type' => 'task'));
        $this->db->delete('tasks', array('task_id' => $task_id));
    }

    function get_task_comments($task_id) {
        $this->db->where('task_id', $task_id);
        $this->db->order_by('log_date', 'desc');
        $this->db
                ->select('task_log.*, employees.name as comment_user, employees.avatar ')
                ->join('employees', 'employees.employee_id = task_log.from_employee', 'LEFT');
        $query = $this->db->get('task_log');
        return $query->result_array();
    }
    
    function get_task_comment($task_comment_id) {
        $this->db->where('id', $task_comment_id);
        $this->db->order_by('log_date', 'desc');
        $this->db
                ->select('task_log.*, employees.name as comment_user, employees.avatar ')
                ->join('employees', 'employees.employee_id = task_log.from_employee', 'LEFT');
        $query = $this->db->get('task_log');
        return $query->row_array();
    }

    function save_task_comment() {
        $employee_id = $this->session->current->userdata('employee_id');
        $data = array(
            'comment' => $this->input->post('comment')
        );


        if ($this->input->post('task_comment_id') == '0') {
            $data['from_employee'] = $employee_id;
            $data['log_date'] = date('Y-m-d H:i:s');
            $data['task_id'] = $this->input->post('task_id');
            $this->db->insert('task_log', $data);
            $result = $task_comment_id = $this->db->insert_id();
        } else {
            $this->db->update('task_log', $data, array('id' => $this->input->post('task_comment_id')));
            $result = TRUE;
            $task_comment_id = $this->input->post('task_comment_id');
        }


//        $this->load->model('attachments_actions');
//        if (!$files = $this->attachments_actions->upload_attachments('task_comment', $task_comment_id)) {
//            return FALSE;
//        }

        $this->db->where('id', $task_comment_id);
        $this->db
                ->select('task_log.*, employees.name as comment_user, employees.avatar')
                ->join('employees', 'employees.employee_id = task_log.from_employee', 'LEFT');
        $query = $this->db->get('task_log');
        $task_comment = $query->row_array();

        return $task_comment;
    }
    
    function delete_comment($task_comment_id) {
        $this->db->delete('task_log', array('id' => $task_comment_id));
    }

    function update_task_process() {
        $task_process = array(
            'process' => $this->input->post('task_process'),
            'updated_date' => date('Y-m-d H:i:s')
        );
        return $this->db->update('tasks', $task_process, array('task_id' => $this->input->post('task_id')));
    }
    
    function update_task_attention() {
        $task_attention = array(
            'task_attention' => $this->input->post('task_attention'),
            'updated_date' => date('Y-m-d H:i:s')
        );
        return $this->db->update('tasks', $task_attention, array('task_id' => $this->input->post('task_id')));
    }
    
    function save_assignment() {
        $update_data = array();
        $data = array(
            'employee_id' => $this->input->post('employee_id'),
            'updated_date' => date('Y-m-d H:i:s')
        );
        
        $task_ids = json_decode($this->input->post('task_ids'));
        
        foreach($task_ids as $key => $task_id) {
            $data['task_id'] = $task_id;
            array_push($update_data, $data);
        }
       // _custom_debug($update_data);
        $this->db->update_batch('tasks', $update_data, 'task_id');
        return TRUE;
    }
    
    function get_employee_tasks($employee_id, $type) {
        switch ($type) {
            case 'all':
                $this->db->where(array('tasks.status !=' => 'completed'));
                break;
            case 'regular':
                $this->db->where(array('tasks.task_regular' => 1));
                break;
            case 'attention':
                $this->db->where(array('tasks.task_attention ' => 'required'));
                break;
            case 'attention_update':
                $this->db->where(array('tasks.task_attention ' => 'updated'));
                break;
            default:
                $this->db->where(array('tasks.status' => $type));
                break;
        }
        
        if (isset($employee_id)) {
            $this->db->where(array('tasks.employee_id' => $employee_id));
        }
        $this->db->order_by('updated_date','desc');
        $query = $this->db
                ->select('tasks.*, employees.name as task_responsible, task_category.task_category_name ')
                ->join('employees', 'employees.employee_id = tasks.employee_id', 'LEFT')
                ->join('task_category', 'task_category.task_category_id = tasks.task_category_id', 'LEFT')
                ->get('tasks');
        //die($this->db->last_query());
        $result = $query->result_array();
        return $result;
    }

}
