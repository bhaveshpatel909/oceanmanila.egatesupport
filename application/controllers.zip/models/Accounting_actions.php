<?php

/**
 * @property CI_Loader           $load
 * @property CI_Form_validation  $form_validation
 * @property CI_Input            $input
 * @property CI_DB_query_builder $db
 * @property CI_Session          $session
 */
class Accounting_actions extends Base_model {

    function save_bir_file() {
        $data = array(
            'form_id' => $this->input->post('form_id'),
            'for_themonth' => $this->input->post('for_themonth'),
            'amount' => $this->input->post('amount'),
            'remarks' => $this->input->post('remarks'),
            'uploaded_date' => date('Y-m-d')
        );

        if ($this->input->post('bir_file_id') == '0') {
            $this->db->insert('bir_files', $data);
            $result = $bir_file_id = $this->db->insert_id();
        } else {
            $this->db->update('bir_files', $data, array('bir_file_id' => $this->input->post('bir_file_id')));
            $result = TRUE;
            $bir_file_id = $this->input->post('bir_file_id');
        }

        $this->load->model('attachments_actions');
        if (!$files = $this->attachments_actions->upload_attachments('bir_file', $bir_file_id)) {
            return FALSE;
        }

        return array_merge($files, array('result' => $result));
    }

    function get_bir_files() {
        return $this->db
                        ->select('bir_files.*, bir_forms.form_name')
                ->join('bir_forms', 'bir_forms.form_id = bir_files.form_id', 'LEFT')
                        ->get('bir_files')
                        ->result_array();
    }

    function get_bir_file($bir_file_id) {
        return $this->db
                        ->select('*')
                        ->where(array('bir_file_id' => $bir_file_id))
                        ->get('bir_files')
                        ->row_array();
    }
    
    function delete_bir_file($bir_file_id) {
        $this->db->delete('bir_files', array('bir_file_id' => $bir_file_id));

        $this->load->model('attachments_actions');
        $this->attachments_actions->remove_attachments('bir_file', $bir_file_id);
    }

}
