<h2>Hello,</h2>
<a href="<?php echo base_url().'welcome/set_password/'.$code?>" target="_blank">Click here</a> to set new password