<link href="css/print_employee_id.css" rel="stylesheet">
<table border="0" border-collapse="collapse" width="60%" align="center">
    <tr>
        <td width="48%" valign="top" style="border: solid 1px #ccc;">
            <table border="0" width="100%" align="center">
                <tr>
                    <td align="center" class=""><img class="logo" style="width: 40px;" src="<?php echo base_url($company['logo']) ?>"/></td>
                </tr>
                <tr>
                    <td align="center" class="padding-left-20 padding-right-20">
                        <?php echo $company['name'] ?><br>
                        <?php echo $company['address'] ?>
                    </td>
                </tr>
            </table>            
            <hr>
            <table border="0" width="90%" align="center">
                <tr>
                    <td width="50%"><img class="avatar" style="width: 80px;border: solid 1px #ccc;" src="<?php echo base_url($employee['avatar']) ?>"/></td>
                    <td width="50%" valign="middle" style="text-align: center">ID NO.</td>
                </tr>
            </table>
            <table border="0" width="90%" align="center">
                <tr>
                    <td valign="middle" style="text-align: center; padding-top: 10px;">
                        <div class="upper-text strong-text employee-name "><?php echo $employee['fullname'] ?></div>
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;padding-top: 5px;" class="border-top">
                        <div class="upper-text small-text ">Name</div>
                    </td>
                </tr>
                <tr>
                    <td valign="middle" style="text-align: center;padding-top: 5px;">
                        <div class="upper-text employee-position"><?php echo $employee['position_name'] ?></div>
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;padding-top: 5px;" class="border-top">
                        <div class="upper-text small-text ">Position</div>
                    </td>
                </tr>
                <tr>
                    <td valign="middle" style="text-align: center;padding-top: 7px;">
                        <div class="upper-text strong-text employee-name">&nbsp;</div>
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;padding-top: 5px;" class="border-top">
                        <div class="upper-text small-text ">Employee's Signature</div>
                    </td>
                </tr>
                <tr>
                    <td valign="middle" style="text-align: center;padding-top: 7px;">
                        &nbsp;
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;padding-top: 5px;" class="border-top">
                        <div class="upper-text small-text ">Human Resource Dept.</div>
                    </td>
                </tr>
            </table>
        </td>
        <td width="4%">&nbsp;</td>
        <td width="48%" valign="top" style="border: solid 1px #ccc;">
            <table border="1" width="90%" align="center" style="margin-top: 15px;">
                <tr>
                    <td style="padding: 4px 2px">SSS NO.: &nbsp; <?php echo $employee['ssn'] ?></td>
                </tr>
                <tr>
                    <td style="padding: 4px 2px">TIN: &nbsp; <?php echo $employee['tin'] ?></td>
                </tr>
                <tr>
                    <td style="padding: 4px 2px">PHILHEALTH NO.: &nbsp; <?php echo $employee['healthno'] ?></td>
                </tr>
            </table>
            <table border="0" width="90%" align="center" style="margin-top: 20px;">
                <tr>
                    <td valign="top" class="line-height" width="30%">Address:</td>
                    <td valign="top" class="line-height"><?php echo $employee['address'] ?>, <?php echo $employee['city'] ?>, <?php echo $employee['state'] ?></td>
                </tr>
                <tr>
                    <td valign="top" class="line-height">Contact No.:</td>
                    <td valign="top" class="line-height"><?php echo $employee['cell_phone'] ?></td>
                </tr>
                <tr>
                    <td valign="top" class="line-height">Birth date:</td>
                    <td valign="top" class="line-height"><?= ($employee['birth_date']) ? date($this->config->item('date_format_pdf'), strtotime($employee['birth_date'])) : '' ?></td>
                </tr>
            </table>
            <table border="0" width="90%" align="center" style="margin-top: 20px;">
                <tr>
                    <td colspan="2" style="text-align: center;padding-bottom: 10px;">In Case of Emergency, Please Notify:</td>
                </tr>
                <tr>
                    <td valign="top" class="line-height" width="40%">Contact Person:</td>
                    <td valign="top" class="line-height"><?php echo $employee['fullname'] ?></td>
                </tr>
                <tr>
                    <td valign="top" class="line-height">Address:</td>
                    <td valign="top" class="line-height"><?php echo $employee['address'] ?></td>
                </tr>
                <tr>
                    <td valign="top" class="line-height">Contact No.:</td>
                    <td valign="top" class="line-height"><?php echo $employee['cell_phone'] ?></td>
                </tr>
            </table>
            <table border="0" width="90%" align="center" style="margin-top: 14px;">
                <tr>
                    <td class="line-height" colspan="2" style="text-align: center;">This is to certify that the person who picture and signature appear on this card is employed by this company.</td>
                </tr>
            </table>
        </td>
    </tr>
</table>