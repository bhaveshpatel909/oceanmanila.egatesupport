<?php $this->load->view('layout/header', array('title' => $this->lang->line('Petty Cash'), 'forms' => TRUE, 'tables' => TRUE, 'icheck' => TRUE)) ?>
<script>
    $('document').ready(function () {
        $(".knob").knob();
        current_table = $('.data_table').dataTable({
            "order": [[0, "desc"]],
            "columnDefs": [{
                    "targets": [1, 7],
                    "orderable": false
                }]
        });
        var options = {aSep: ',', aDec: '.', aSign: '₱ ', mDec: 0};
        $('.autoNumeric').autoNumeric('init', options);
    });
</script>
<div id="wrapper">
    <?php $this->load->view('layout/menu', array('active_menu' => 'petty_cash')) ?>
    <div id="page-wrapper" class="gray-bg">
        <?php $this->load->view('layout/page_header') ?>

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-8">
                <h2><?= $this->lang->line('Tasks') ?></h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="dashboard"><?= $this->lang->line('Home') ?></a>
                    </li>
                    <li>
                        <?= $this->lang->line('Petty Cash') ?>
                    </li>
                </ol>
            </div>
            <div class="col-lg-4">
                <div class="title-action">
                    <a href="petty/new_petty_cash" class="btn btn-primary">
                        <i class="fa fa-plus-circle"></i>
                        <?= $this->lang->line('Add') ?>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInDown">
                    <div class="ibox-content">
                        <div class="row">
                            <div id="save_result"></div>
                            <table class="table table-striped table-bordered table-hover data_table" >
                                <thead>
                                    <tr>
                                        <th width="8%"><?= $this->lang->line('Date') ?></th>
                                        <th><?= $this->lang->line('Voucher No.') ?></th>
                                        <th><?= $this->lang->line('Description') ?></th>
                                        <th><?= $this->lang->line('Pay to') ?></th>
                                        <th align="right"><?= $this->lang->line('Expense') ?></th>
                                        <th align="right"><?= $this->lang->line('Deposit') ?></th>
                                        <th align="right"><?= $this->lang->line('Balance') ?></th>
                                        <th width="7%"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $expense = $deposit = $balance = 0;
                                    foreach ($petty_cash_list as $petty_cash) {
                                        if ($petty_cash['petty_cash_type'] == 'expense') {
                                            $petty_cash['expense'] = $petty_cash['total'];
                                            $petty_cash['deposit'] = 0;
                                            $expense += $petty_cash['total'];
                                            $balance = $balance - $petty_cash['total'];
                                        } else {
                                            $petty_cash['expense'] = 0;
                                            $petty_cash['deposit'] = $petty_cash['total'];
                                            $deposit += $petty_cash['total'];
                                            $balance = $balance + $petty_cash['total'];
                                        }
                                        ?>
                                        <tr entity_id="<?= $petty_cash['petty_cash_id'] ?>">
                                            <td><?= $petty_cash['created_date'] ?></td>
                                            <td><?= $petty_cash['ca_no'] ?></td>
                                            <td>
                                                <a class="btn btn-outline btn-primary btn-xs" target="_blank" href="petty/preview_petty_cash/<?= $petty_cash['petty_cash_id'] ?>" >
                                                    <i class="fa fa-file-pdf-o"></i>
                                                </a>
                                                <?= $petty_cash['description'] ?>
                                            </td>
                                            <td><?= $petty_cash['fullname'] ?></td>
                                            <td align="right">
                                                <span class="autoNumeric"><?= $petty_cash['expense'] ?></span>
                                            </td>
                                            <td align="right">
                                                <span class="autoNumeric"><?= $petty_cash['deposit'] ?></span>
                                            </td>
                                            <td align="right"><span class="autoNumeric"><?= $balance ?></span></td>
                                            <td>
                                                <?php if ($this->user_actions->is_allowed('admin')) { ?>
                                                    <a class="btn btn-outline btn-success btn-xs" href="petty/edit_petty_cash/<?= $petty_cash['petty_cash_id'] ?>" >
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <a class="btn btn-outline btn-danger btn-xs" onclick="confirm('Delete petty_cash ?') && submit_form('#delete_petty_cash<?= $petty_cash['petty_cash_id'] ?>', '#save_result')" title="Delete">
                                                        <i class="fa fa-trash-o"></i>
                                                    </a>
                                                <?php } ?>

                                                <form action="petty/delete_petty_cash" method="POST" id="delete_petty_cash<?= $petty_cash['petty_cash_id'] ?>">
                                                    <input type="hidden" id="petty_cash_id" name="petty_cash_id" value="<?= $petty_cash['petty_cash_id'] ?>" class="petty_cash_id<?= $petty_cash['petty_cash_id'] ?>">
                                                </form>
                                            </td>
                                        </tr>                                    
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                <th colspan="4"><?= $this->lang->line('Total') ?></th>
                                <td align="right"><span class="autoNumeric" style="font-weight: 700;"><?= $expense ?></span></td>
                                <td align="right"><span class="autoNumeric" style="font-weight: 700;"><?= $deposit ?></span></td>
                                <td align="right"><span class="autoNumeric" style="font-weight: 700;"><?= $balance ?></span></td>
                                <th></th>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</div>
<?php
$this->load->view('layout/footer')?>